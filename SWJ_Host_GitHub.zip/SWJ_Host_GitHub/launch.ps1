﻿param([switch]$Source)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$errorLog = Join-Path $PSScriptRoot 'startup_error.log'
$launchLog = Join-Path $PSScriptRoot 'launch.log'
try {
    $identity = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'app_identity.json') -Encoding UTF8 -Raw | ConvertFrom-Json
    $executable = Join-Path $PSScriptRoot $identity.executable
    if (-not $Source -and (Test-Path -LiteralPath $executable -PathType Leaf)) {
        $started = Start-Process -FilePath $executable -WorkingDirectory $PSScriptRoot -PassThru
        "$(Get-Date -Format o) mode=portable pid=$($started.Id)" | Add-Content -LiteralPath $launchLog -Encoding UTF8
        exit 0
    }
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    $pythonw = Join-Path $PSScriptRoot '.venv\Scripts\pythonw.exe'
    if (-not (Test-Path -LiteralPath $python)) {
        throw '当前目录是源码版，尚未安装运行环境。直接运行请使用包含 EXE 的便携包；源码运行请先安装 64 位 Python 3.12，再执行 Setup.cmd。'
    }
    & $python -c "import PyQt6.QtWidgets, PyQt6.QtNetwork, numpy"
    if ($LASTEXITCODE -ne 0) { throw 'Python 依赖不完整，请执行 Setup.cmd 后重试。' }
    if (-not (Test-Path -LiteralPath $pythonw)) { $pythonw = $python }
    $main = Join-Path $PSScriptRoot 'main.py'
    $started = Start-Process -FilePath $pythonw -ArgumentList ('"' + $main + '"') -WorkingDirectory $PSScriptRoot -PassThru
    "$(Get-Date -Format o) mode=source pid=$($started.Id)" | Add-Content -LiteralPath $launchLog -Encoding UTF8
    exit 0
} catch {
    $detail = "$(Get-Date -Format o)`r`n$($_ | Out-String)"
    $detail | Set-Content -LiteralPath $errorLog -Encoding UTF8
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
