param([string]$ExePath, [string]$ReportDirectory)
$ErrorActionPreference = "Stop"
$resolvedExe = (Resolve-Path -LiteralPath $ExePath).Path
$reportPath = [System.IO.Path]::GetFullPath($ReportDirectory)
New-Item -ItemType Directory -Path $reportPath -Force | Out-Null
$keys = @("PATH", "PYTHONPATH", "PYTHONHOME", "QT_QPA_PLATFORM", "QT_PLUGIN_PATH")
$previousEnvironment = @{}
foreach ($key in $keys) { $previousEnvironment[$key] = [Environment]::GetEnvironmentVariable($key, "Process") }
$launch = $null
try {
    $env:PATH = "$env:WINDIR\System32;$env:WINDIR"
    $env:PYTHONPATH = ""
    $env:PYTHONHOME = ""
    $env:QT_QPA_PLATFORM = "windows"
    $env:QT_PLUGIN_PATH = ""
    $nativeImage = Join-Path $reportPath "native-window.png"
    $launchArgs = @("--screenshot", $nativeImage, "--data-dir", "$reportPath\data")
    $launch = Start-Process -FilePath $resolvedExe -ArgumentList $launchArgs -WindowStyle Hidden -PassThru
    if (-not $launch.WaitForExit(25000)) { throw "Native Windows application did not finish within 25 seconds." }
    $launch.Refresh()
    if ($launch.ExitCode -ne 0) { throw "Native Windows startup failed: exit $($launch.ExitCode)." }
    $capture = Get-Content -LiteralPath (Join-Path $reportPath "native-window.json") -Raw | ConvertFrom-Json
    if ($capture.platform -ne "windows") { throw "Expected Windows Qt platform, got $($capture.platform)." }
    if (-not (Test-Path -LiteralPath $nativeImage)) { throw "Native Windows screenshot was not generated." }
    $report = @{
        ok = $true; platform = $capture.platform; exit_code = $launch.ExitCode
        python_on_path = $false; screenshot = $nativeImage; exe = $resolvedExe
    }
    $report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $reportPath "native-startup.json") -Encoding utf8
    $report | ConvertTo-Json
} finally {
    if ($launch -and -not $launch.HasExited) {
        $children = Get-CimInstance Win32_Process -Filter "ParentProcessId = $($launch.Id)"
        $ownedIds = @($launch.Id) + @($children | Where-Object { $_.ExecutablePath -eq $resolvedExe } | Select-Object -ExpandProperty ProcessId)
        foreach ($ownedId in $ownedIds) {
            $remaining = Get-Process -Id $ownedId -ErrorAction SilentlyContinue
            if ($remaining -and $remaining.Path -eq $resolvedExe) { Stop-Process -Id $ownedId -Force -ErrorAction SilentlyContinue }
        }
    }
    foreach ($key in $keys) { [Environment]::SetEnvironmentVariable($key, $previousEnvironment[$key], "Process") }
}
