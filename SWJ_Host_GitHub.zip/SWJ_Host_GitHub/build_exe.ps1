param([switch]$InstallDependencies)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$venvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $venvPython)) { throw "Run Setup.cmd first." }
if ($InstallDependencies) {
    & $venvPython -m pip install -r (Join-Path $PSScriptRoot "requirements-build.txt")
    if ($LASTEXITCODE -ne 0) { throw "Build dependencies failed." }
}
$previousPath = $env:PATH
try {
    $env:PATH = ($previousPath -split ";" | Where-Object { $_ -notmatch "(?i)poppler" }) -join ";"
    $buildArguments = @(
        "--noconfirm", "--clean", "--distpath", $PSScriptRoot,
        "--workpath", (Join-Path $PSScriptRoot "build"),
        (Join-Path $PSScriptRoot "SignalDesk.spec")
    )
    & $venvPython -m PyInstaller @buildArguments
    if ($LASTEXITCODE -ne 0) { throw "Packaging failed. Install requirements-build.txt if PyInstaller is missing." }
} finally {
    $env:PATH = $previousPath
}
Write-Host "Ready: $PSScriptRoot\路由不迷路信号处理平台.exe (single file; Python is not required on the target PC)"
