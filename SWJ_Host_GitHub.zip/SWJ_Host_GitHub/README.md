# 路由不迷路信号处理平台

基于 PyQt6 的 FPGA 信号处理上位机，支持 Zynq UDP 通信、MIMO/CDMA 文件下发与结果接收，以及 MIMO、CDMA、AMC 三个结果页面。

## 直接运行便携版

解压完整的 `SWJ_Host_GitHub.zip`，双击 `Start.cmd`，或直接双击 `路由不迷路信号处理平台.exe`。此方式无需 Python、无需 Setup，也无需联网安装依赖。

启动入口优先运行同目录的 EXE。若启动失败，窗口会保留错误提示，并写入 `startup_error.log`；启动方式记录在 `launch.log`。

## GitHub 源码与便携包的区别

`.gitignore` 排除了 EXE，因此 GitHub 克隆得到的源码目录需要按下文安装 Python 依赖。需要让评委直接运行时，将完整便携 ZIP 作为附件或 Release 提供。源码 ZIP 为 `SWJ_Host_source.zip`。

## 源码运行

环境：Windows、64 位 Python 3.12（已验证版本）。首次安装依赖需要联网。

1. 双击 `Setup.cmd`，创建 `.venv` 并安装依赖。
2. 双击 `Start.cmd` 启动；也可使用 `Start.cmd --source` 强制运行源码。

命令行方式：

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

## 连接与文件下发

选择实际网卡的本机 IPv4 和端口，填写 Zynq 的 IPv4 和端口，再点击“连接 FPGA”。握手应答表示 Zynq UDP 程序已响应。

选择 MIMO 或 CDMA，按板端工程的流程完成复位和 VIO 工作模式设置，选取有效 PM、CM、DM 文件并依次下发。协议和固件要求见 [通信协议](docs/PROTOCOL.md)。本仓库不附 FPGA 工程、有效 3M 映像或训练权重，请使用与实际板端工程匹配的文件。

AMC 页面支持结果文件与 I/Q 文件读取。当前版本的分类值来自结果文件，FFT/时频特征由 PC 计算；AMC 板端程序与旧固件传输适配尚未实现。接口见 [AMC 数据格式](docs/AMC_INTERFACE.md)。

## 本地文件与运行数据

在“算法结果”中点击“载入本地结果”，或在 AMC 页面点击“载入 AMC 结果”“载入 I/Q”，可选取外部文件。实际实验数据可放到程序目录的 `本地数据文件`，无需提交到 Git。

软件启动后保持空白，不自动生成或载入案例。设置、接收结果和日志保存在运行目录，它们均已加入忽略规则。

## 自动化测试

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

`tests/fixtures` 只保存测试必需的小文件。它们是 PC 参考数据，不是板端实测结果，也不能作为 PM/CM/DM 下发。

## 打包 Windows EXE

```powershell
powershell -ExecutionPolicy Bypass -File .\build_exe.ps1 -InstallDependencies
```

生成的 `路由不迷路信号处理平台.exe` 可独立运行，不要求目标电脑安装 Python。EXE 不提交到源码仓库；需要提供下载时，可单独放入 GitHub Release。打包文件、虚拟环境、历史备份及本机设置均不属于源码交付。

## 目录

```text
host615/          应用源码，保留内部包名以兼容现有入口
assets/           图标资源
docs/             通信协议与 AMC 数据格式
tests/            自动化测试与小型测试数据
tools/            EXE 原生启动检查脚本
main.py           应用入口
SignalDesk.spec   PyInstaller 打包配置
```

上传 GitHub 时提交本目录的源码文件即可，不必再次压缩或加入原始 SWJ_Host 目录。上传前使用 `git status --short` 检查待提交列表。
