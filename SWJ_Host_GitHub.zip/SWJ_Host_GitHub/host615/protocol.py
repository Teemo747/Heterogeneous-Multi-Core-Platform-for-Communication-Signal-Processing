"""Wire format verified against udp_perf_server.c, main.c and dma_top_SAR.c.

All commands are bare ASCII bytes, with no NUL, newline or invented header.
File payloads are sent unchanged.  The firmware has no per-packet ACK.
"""

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Iterator


@dataclass(frozen=True)
class Algorithm:
    key: str
    title: str
    command: bytes
    result_bytes: int
    subtitle: str


ALGORITHMS = {
    "mimo": Algorithm("mimo", "MIMO 波形检测", b"algo_Air", 65024, "星座图 · 16 核协作"),
    "cdma": Algorithm("cdma", "CDMA 解扩", b"algocdma", 256, "比特流 · 误码分析"),
}
MEMORIES = ("PM", "CM", "DM")


def hello(memory: str) -> bytes:
    if memory not in MEMORIES:
        raise ValueError("未知存储区")
    return b"hello_" + memory.lower().encode("ascii")


def end(memory: str) -> bytes:
    if memory not in MEMORIES:
        raise ValueError("未知存储区")
    return b"end_" + memory.lower().encode("ascii")


def firmware_treats_as_control(data: bytes) -> bool:
    """Match the actual callback's prefix AND length tests, including bad IDs."""
    return (
        len(data) == 8 and (data.startswith(b"hello") or data.startswith(b"algo"))
    ) or (len(data) == 6 and data.startswith(b"end"))


def file_packets(paths: list[Path], chunk_size: int = 1024) -> Iterator[bytes]:
    """Concatenate selected files in order; preserve every byte.

    A short file tail can accidentally match the firmware command tests.
    Splitting that datagram into two safe datagrams avoids the collision
    without padding, escaping, or changing the concatenated file.
    """
    if not 16 <= chunk_size <= 1400:
        raise ValueError("分包长度需在 16–1400 字节之间")
    for path in paths:
        with path.open("rb") as stream:
            while data := stream.read(chunk_size):
                if firmware_treats_as_control(data):
                    yield data[:1]
                    yield data[1:]
                else:
                    yield data


# Legacy telemetry remains reserved so it cannot become binary payload.
_PATTERNS = (
    (re.compile(rb"core16status([0-9A-Fa-f]{4})"), "cores"),
    (re.compile(rb"algor_time([0-9A-Fa-f]{4})"), "algorithm_time"),
    (re.compile(rb"msg_sar_stage([0-9A-Fa-f]{2})"), "sar_stage"),
    (re.compile(rb"sar_stage_time([0-9A-Fa-f]{16})"), "sar_times"),
)


def parse_control(data: bytes) -> tuple[str, object] | None:
    if data in (b"hello_pm", b"hello_cm", b"hello_dm"):
        return "hello", data
    if data == b"finished":
        return "finished", None
    if data == b"core16finish":
        return "cores_finished", 0
    for pattern, kind in _PATTERNS:
        match = pattern.fullmatch(data)
        if match:
            value = match.group(1)
            if kind == "sar_times":
                return kind, [int(value[i:i + 4], 16) for i in range(0, 16, 4)]
            return kind, int(value, 16)
    return None


def readable_size(value: int | float) -> str:
    for suffix in ("B", "KiB", "MiB", "GiB"):
        if abs(value) < 1024 or suffix == "GiB":
            return f"{value:.0f} {suffix}" if suffix == "B" else f"{value:.2f} {suffix}"
        value /= 1024
    return str(value)
