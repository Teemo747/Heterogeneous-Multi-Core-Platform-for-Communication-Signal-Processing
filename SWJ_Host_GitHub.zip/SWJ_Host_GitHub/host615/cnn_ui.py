"""AMC file viewer and local FFT analysis."""
from datetime import datetime
from pathlib import Path
import time

import numpy as np
from PyQt6.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPolygonF
from PyQt6.QtWidgets import (QComboBox, QDoubleSpinBox, QFileDialog, QGridLayout, QHBoxLayout,
                            QLabel, QLineEdit, QPlainTextEdit, QProgressBar, QPushButton, QTableWidget,
                            QTableWidgetItem, QHeaderView, QTabWidget, QVBoxLayout, QWidget)

from .branding import APP_TITLE
from .cnn import (CLASSES, CLASS_NAMES, FFT_SIZE, HOP, compute_features,
                  export_iq, load_iq, load_result, save_result)
from .widgets import Card, Metric


def text(value, name=None):
    label = QLabel(value); label.setTextFormat(Qt.TextFormat.PlainText)
    if name:
        label.setObjectName(name)
    return label


def action(value, callback, primary=False):
    button = QPushButton(value); button.clicked.connect(callback)
    if primary:
        button.setObjectName("primary")
    return button


def paint_plot(p, rect, title, x, traces, ylim=None, xlabel="", ylabel=""):
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("white")); p.drawRoundedRect(rect, 10, 10)
    p.setPen(QColor("#233b52")); p.setFont(QFont("Microsoft YaHei UI", 10, QFont.Weight.Bold))
    heading = title + (" / " + ylabel if ylabel else "")
    p.drawText(QRectF(rect.left()+14, rect.top()+8, rect.width()-28, 24), Qt.AlignmentFlag.AlignVCenter, heading)
    box = rect.adjusted(58, 40, -18, -39)
    p.setFont(QFont("Segoe UI", 8)); p.setPen(QColor("#e5edf4"))
    for i in range(5):
        xx = box.left()+box.width()*i/4; yy = box.top()+box.height()*i/4
        p.drawLine(QPointF(xx, box.top()), QPointF(xx, box.bottom()))
        p.drawLine(QPointF(box.left(), yy), QPointF(box.right(), yy))
    if x is not None and len(x):
        lo, hi = float(x[0]), float(x[-1])
        if xlabel == "频率 kHz" and lo < 0 < hi:
            span = max(abs(lo), abs(hi)); lo, hi = -span, span
        if hi <= lo:
            hi = lo+1
        bottom, top = ylim or (min(float(v.min()) for v, _, _ in traces), max(float(v.max()) for v, _, _ in traces))
        if top <= bottom:
            top = bottom+1
        if ylim is None:
            pad = (top-bottom)*.12; bottom -= pad; top += pad
        p.save(); p.setClipRect(box)
        for values, color, _ in traces:
            px = box.left()+(x-lo)/(hi-lo)*box.width()
            py = box.bottom()-(values-bottom)/(top-bottom)*box.height()
            polygon = QPolygonF([QPointF(float(a), float(b)) for a, b in zip(px, py)])
            p.setPen(QPen(QColor(color), 1.15)); p.drawPolyline(polygon)
        p.restore(); p.setPen(QColor("#71869a"))
        for i in range(3):
            yy = box.bottom()-box.height()*i/2
            p.drawText(QRectF(rect.left(), yy-9, 50, 20), Qt.AlignmentFlag.AlignRight, f"{bottom+(top-bottom)*i/2:.3g}")
            xx = box.left()+box.width()*i/2
            p.drawText(QRectF(xx-35, box.bottom()+5, 70, 18), Qt.AlignmentFlag.AlignCenter, f"{lo+(hi-lo)*i/2:.3g}")
        offset = rect.right()-20
        for _, color, name in reversed(traces):
            width = p.fontMetrics().horizontalAdvance(name)+24
            p.setPen(QColor(color)); p.drawText(QRectF(offset-width, rect.top()+9, width, 23), Qt.AlignmentFlag.AlignRight, name)
            offset -= width
    p.setPen(QColor("#7c8fa3")); p.setFont(QFont("Microsoft YaHei UI", 8))
    p.drawText(QRectF(box.right()-100, rect.bottom()-18, 100, 16), Qt.AlignmentFlag.AlignRight, xlabel)
    p.restore()


class RadioPlot(QWidget):
    def __init__(self, title, xlabel, ylabel, ylim=None):
        super().__init__(); self.title = title; self.xlabel = xlabel; self.ylabel = ylabel; self.ylim = ylim
        self.x = None; self.traces = []
        self.setMinimumSize(280, 170)

    def set_data(self, x, traces):
        self.x = np.asarray(x); self.traces = traces; self.update()

    def clear(self):
        self.x = None; self.traces = []; self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        paint_plot(p, QRectF(self.rect()), self.title, self.x, self.traces, self.ylim, self.xlabel, self.ylabel)
        p.end()


def tf_image(features):
    value = np.clip((features["tf_db"]+65)/65, 0, 1)
    # Blue -> cyan -> yellow color map; brighter pixels represent more power.
    anchors = np.array([[14, 33, 63], [27, 74, 131], [18, 148, 161], [102, 202, 157], [255, 218, 101]], dtype=float)
    pos = value*4; index = np.minimum(pos.astype(int), 3); fraction = (pos-index)[..., None]
    rgb = np.ascontiguousarray(np.round(anchors[index]*(1-fraction)+anchors[index+1]*fraction).astype(np.uint8))
    return QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QImage.Format.Format_RGB888).copy()


def paint_tf(p, rect, features, title="03  时频特征 · PC 分帧 FFT"):
    p.save(); p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("white")); p.drawRoundedRect(rect, 10, 10)
    p.setPen(QColor("#233b52")); p.setFont(QFont("Microsoft YaHei UI", 10, QFont.Weight.Bold))
    p.drawText(QRectF(rect.left()+14, rect.top()+8, rect.width()-28, 24), Qt.AlignmentFlag.AlignVCenter, title)
    box = rect.adjusted(62, 39, -65, -33)
    if features is not None:
        p.drawImage(box, tf_image(features))
        p.setFont(QFont("Segoe UI", 8)); p.setPen(QColor("#71869a"))
        fs = features["sample_rate_hz"]/2000
        for i in range(3):
            xx = box.left()+box.width()*i/2
            p.drawText(QRectF(xx-35, box.bottom()+4, 70, 18), Qt.AlignmentFlag.AlignCenter, f"{-fs+fs*i:g}")
            yy = box.top()+box.height()*i/2
            t = float(features["time_ms"][0]+(features["time_ms"][-1]-features["time_ms"][0])*i/2)
            p.drawText(QRectF(rect.left()+4, yy-9, 49, 20), Qt.AlignmentFlag.AlignRight, f"{t:.2f}")
        ramp = {**features, "tf_db": np.linspace(0, -65, 100)[:, None]}
        color_box = QRectF(box.right()+12, box.top(), 10, box.height())
        p.drawImage(color_box, tf_image(ramp))
        for i, label in enumerate(("0", "−32", "−65")):
            p.drawText(QRectF(color_box.right()+3, box.top()+i*box.height()/2-8, 30, 18), Qt.AlignmentFlag.AlignLeft, label)
        p.drawText(QRectF(rect.right()-38, rect.top()+21, 30, 18), Qt.AlignmentFlag.AlignLeft, "dB")
    p.setFont(QFont("Microsoft YaHei UI", 8)); p.setPen(QColor("#71869a"))
    p.save(); p.translate(rect.left()+12, box.center().y()); p.rotate(-90)
    p.drawText(QRectF(-40, -8, 80, 16), Qt.AlignmentFlag.AlignCenter, "时间 ms"); p.restore()
    p.drawText(QRectF(box.right()-90, rect.bottom()-17, 90, 16), Qt.AlignmentFlag.AlignRight, "频率 kHz")
    p.restore()


class Spectrogram(QWidget):
    def __init__(self):
        super().__init__(); self.features = None; self.setMinimumSize(320, 178)

    def set_features(self, features):
        self.features = features; self.update()

    def paintEvent(self, event):
        p = QPainter(self); paint_tf(p, QRectF(self.rect()), self.features); p.end()


def paint_constellation(p, rect, sample):
    p.save(); p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("white")); p.drawRoundedRect(rect, 10, 10)
    p.setPen(QColor("#233b52")); p.setFont(QFont("Microsoft YaHei UI", 10, QFont.Weight.Bold))
    aligned = sample is not None and sample.samples_per_symbol is not None
    title = "03  符号抽样散点" if aligned else "03  原始 I/Q 散点"
    p.drawText(QRectF(rect.left()+14, rect.top()+5, rect.width()-28, 24), Qt.AlignmentFlag.AlignVCenter, title)
    p.setFont(QFont("Microsoft YaHei UI", 8)); p.setPen(QColor("#7a8fa2"))
    if sample is not None:
        if aligned:
            values = sample.iq[sample.symbol_offset::sample.samples_per_symbol]
            caption = f"按文件参数抽样 · 每符号 {sample.samples_per_symbol} 点 · 未执行盲同步"
        else:
            values = sample.iq
            caption = "未提供符号对齐信息，显示原始采样；不据此自动判断调制方式"
        p.drawText(QRectF(rect.left()+14, rect.top()+27, rect.width()-28, 18), Qt.AlignmentFlag.AlignVCenter, caption)
        box = rect.adjusted(52, 53, -22, -28)
        extent = max(float(np.quantile(np.abs(values), .995))*1.25, 1)
        aspect = box.width()/max(1, box.height())
        xmax = extent*max(1, aspect); ymax = extent*max(1, 1/aspect)
        p.setPen(QPen(QColor("#e5edf4"), 1))
        for i in range(5):
            x = box.left()+box.width()*i/4; y = box.top()+box.height()*i/4
            p.drawLine(QPointF(x, box.top()), QPointF(x, box.bottom()))
            p.drawLine(QPointF(box.left(), y), QPointF(box.right(), y))
        shown = values[::max(1, len(values)//4096)]
        px = box.center().x()+shown.real/xmax*box.width()/2
        py = box.center().y()-shown.imag/ymax*box.height()/2
        p.save(); p.setClipRect(box); p.setPen(QPen(QColor(10, 151, 136, 160), 2.7))
        p.drawPoints(QPolygonF([QPointF(float(x), float(y)) for x, y in zip(px, py)])); p.restore()
        p.setFont(QFont("Segoe UI", 8)); p.setPen(QColor("#7a8fa2"))
        for i in range(3):
            p.drawText(QRectF(rect.left()+2, box.bottom()-box.height()*i/2-8, 43, 18), Qt.AlignmentFlag.AlignRight, f"{-ymax+ymax*i:.2g}")
            p.drawText(QRectF(box.left()+box.width()*i/2-30, box.bottom()+3, 60, 18), Qt.AlignmentFlag.AlignCenter, f"{-xmax+xmax*i:.2g}")
        p.drawText(QRectF(box.right()-30, rect.bottom()-16, 30, 15), Qt.AlignmentFlag.AlignRight, "I")
        p.drawText(QRectF(rect.left()+4, box.top()-18, 30, 15), Qt.AlignmentFlag.AlignRight, "Q")
    p.restore()


class ConstellationView(QWidget):
    def __init__(self):
        super().__init__(); self.sample = None; self.setMinimumSize(320, 178)

    def set_sample(self, sample):
        self.sample = sample; self.update()

    def paintEvent(self, event):
        p = QPainter(self); paint_constellation(p, QRectF(self.rect()), self.sample); p.end()


class AMCPage(QWidget):
    message = pyqtSignal(str, str)
    finished = pyqtSignal(object)

    def __init__(self, base):
        super().__init__(); self.base = base; self.result = None; self.result_path = None
        self.input_sample = None; self.features = None; self.fft_ms = 0
        self.busy = False; self.records = []
        layout = QVBoxLayout(self); layout.setContentsMargins(14, 12, 14, 12); layout.setSpacing(8)
        header = QHBoxLayout(); names = QVBoxLayout(); names.setSpacing(1)
        title = text("AMC 自动调制识别 · FFT＋CNN"); title.setStyleSheet("font-size:22px;font-weight:700;color:#17384d;")
        names.addWidget(title); names.addWidget(text("BPSK / QPSK / 8PSK / 16QAM · I/Q 与复数 FFT 特征融合", "muted"))
        header.addLayout(names); header.addStretch()
        self.source_badge = text("未载入文件")
        self.source_badge.setStyleSheet("background:#e0f5f0;color:#087e70;padding:8px 13px;border-radius:11px;font-weight:600;")
        header.addWidget(self.source_badge); layout.addLayout(header)
        self.notice = text("载入结果文件查看类别与得分；载入 I/Q 可查看波形及频域特征。")
        self.notice.setWordWrap(True)
        self.notice.setStyleSheet("background:#fff6e6;color:#92692b;padding:8px 12px;border-radius:6px;font-size:11px;")
        layout.addWidget(self.notice)
        controls = QHBoxLayout()
        self.file_path = QLineEdit(); self.file_path.setReadOnly(True)
        self.file_path.setPlaceholderText("选择本地 AMC 结果或 I/Q 文件")
        controls.addWidget(self.file_path, 1)
        self.iq_button = action("载入 I/Q", self.choose_iq)
        self.import_button = action("载入 AMC 结果", self.choose_result, True)
        self.export_button = action("导出图像及数据", self.export_result)
        for item in (self.import_button, self.iq_button, self.export_button):
            controls.addWidget(item)
        layout.addLayout(controls)
        config = QHBoxLayout()
        self.fs = QDoubleSpinBox(); self.fs.setDecimals(3); self.fs.setRange(.001, 1000); self.fs.setValue(1); self.fs.setSuffix(" MHz"); self.fs.setFixedWidth(105)
        config.addWidget(text("导入采样率")); config.addWidget(self.fs)
        self.iq_format = QComboBox(); self.iq_format.addItem("int16 小端 · I/Q 交错", "int16"); self.iq_format.addItem("float32 小端 · I/Q 交错", "float32")
        config.addWidget(self.iq_format)
        self.export_iq_button = action("导出 I/Q 样本", self.choose_export_iq)
        config.addStretch(); config.addWidget(self.export_iq_button); layout.addLayout(config)
        metrics = QHBoxLayout()
        self.class_metric = Metric("识别调制方式", "待识别", "BPSK / QPSK / 8PSK / 16QAM")
        self.score_metric = Metric("最高分类得分", "—", "得分来自结果文件")
        self.time_metric = Metric("PC FFT 计算耗时", "—", "本机计算，不是 FPGA 耗时")
        self.frame_metric = Metric("本页分类记录", "00", "独立于板端结果帧计数")
        for metric in (self.class_metric, self.score_metric, self.time_metric, self.frame_metric):
            metric.setMaximumHeight(76); metrics.addWidget(metric)
        layout.addLayout(metrics)
        plots = QGridLayout(); plots.setSpacing(8)
        self.wave_plot = RadioPlot("01  输入 I/Q · 前 1024 点", "时间 ms", "幅值")
        self.spectrum_plot = RadioPlot("02  FFT 平均功率谱 · PC", "频率 kHz", "相对 dB", (-75, 3))
        self.wave_plot.setMinimumHeight(160)
        self.spectrum_plot.setMinimumHeight(160)
        self.spectrogram = Spectrogram()
        self.constellation = ConstellationView()
        self.fft_complex_plot = RadioPlot("FFT 复数特征 · 首窗", "频率 kHz", "归一化幅值")
        self.fft_complex_plot.setMinimumHeight(178)
        self.feature_tabs = QTabWidget()
        self.feature_tabs.setStyleSheet("QTabBar::tab {padding:6px 12px;}")
        self.feature_tabs.addTab(self.constellation, "符号散点")
        self.feature_tabs.addTab(self.spectrogram, "时频分析")
        self.feature_tabs.addTab(self.fft_complex_plot, "FFT 实部 / 虚部")
        for row, col, widget in ((0, 0, self.wave_plot), (0, 1, self.spectrum_plot), (1, 0, self.feature_tabs)):
            plots.addWidget(widget, row, col)
        scores = Card(); scores_layout = QVBoxLayout(scores); scores_layout.setContentsMargins(14, 10, 14, 10); scores_layout.setSpacing(5)
        scores_layout.addWidget(text("04  AMC 分类得分", "section")); self.score_rows = {}
        for key in CLASSES:
            line = QHBoxLayout(); name = text(CLASS_NAMES[key]); name.setFixedWidth(78)
            bar = QProgressBar(); bar.setRange(0, 1000); bar.setTextVisible(False)
            value = text("—", "muted"); value.setFixedWidth(49); value.setAlignment(Qt.AlignmentFlag.AlignRight)
            line.addWidget(name); line.addWidget(bar, 1); line.addWidget(value); scores_layout.addLayout(line)
            self.score_rows[key] = bar, value
        self.detail_note = text("等待结果文件。单独载入 I/Q 时不生成分类结论。", "small")
        self.detail_note.setWordWrap(True); scores_layout.addWidget(self.detail_note)
        self.inference_note = text("板端 CNN 推理耗时：待接入", "small"); scores_layout.addWidget(self.inference_note)
        plots.addWidget(scores, 1, 1); plots.setColumnStretch(0, 1); plots.setColumnStretch(1, 1)
        layout.addLayout(plots, 1)
        self.input_caption = text("", "small"); self.input_caption.setWordWrap(True); layout.addWidget(self.input_caption)
        footer = QHBoxLayout(); self.phase = text("等待载入", "muted"); footer.addWidget(self.phase)
        self.progress = QProgressBar(); self.progress.setTextVisible(False); footer.addWidget(self.progress, 1)
        self.history_button = action("查看识别记录", self.toggle_history); footer.addWidget(self.history_button); layout.addLayout(footer)
        self.process = QPlainTextEdit(); self.process.setReadOnly(True); self.process.setMaximumBlockCount(80); self.process.setFixedHeight(57)
        layout.addWidget(self.process)
        self.history = QTableWidget(0, 5); self.history.setHorizontalHeaderLabels(["时间", "来源", "类别", "得分", "PC FFT / ms"])
        self.history.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.history.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers); self.history.setFixedHeight(150); self.history.hide(); layout.addWidget(self.history)
        self._clear_result()
        self.export_iq_button.setEnabled(False)

    def log(self, value):
        self.process.appendPlainText(datetime.now().strftime("%H:%M:%S  ")+value)

    def _clear_result(self):
        self.result = None; self.result_path = None; self.class_metric.value.setText("待分类"); self.score_metric.value.setText("—")
        self.progress.setValue(0); self.phase.setText("等待分类结果"); self.export_button.setEnabled(False)
        self.inference_note.setText("板端 CNN 推理耗时：待接入")
        for bar, label in self.score_rows.values():
            bar.setValue(0); label.setText("—")

    def analyze(self):
        start = time.perf_counter(); sample = self.input_sample
        self.features = compute_features(sample.iq, sample.sample_rate_hz)
        self.fft_ms = (time.perf_counter()-start)*1000
        self.time_metric.value.setText(f"{self.fft_ms:.2f} ms")
        count = min(1024, len(sample.iq)); iq = sample.iq[:count]
        self.wave_plot.set_data(np.arange(count)/sample.sample_rate_hz*1000, [(iq.real, "#12988c", "I"), (iq.imag, "#6c7bd4", "Q")])
        self.spectrum_plot.set_data(self.features["frequency_khz"], [(self.features["spectrum_db"], "#12988c", "功率谱")])
        self.spectrogram.set_features(self.features)
        self.constellation.set_sample(sample)
        first = self.features["cnn_input"][0]
        self.fft_complex_plot.set_data(self.features["frequency_khz"], [(first[2], "#12988c", "Re"), (first[3], "#6c7bd4", "Im")])
        self.input_caption.setText(f"{sample.sample_name} · {len(sample.iq):,} 个复数采样 · Fs {sample.sample_rate_hz/1e6:g} MHz · "
                                   f"FFT {FFT_SIZE} / 步长 {HOP} · {len(self.features['time_ms'])} 个时间窗 · 特征 {self.features['cnn_input'].shape[0]} × 4 × 1024")


    def display_result(self, result):
        self.input_sample = result; self.result = result; self.analyze()
        self.class_metric.value.setText(CLASS_NAMES[result.winner]); self.score_metric.value.setText(f"{result.scores[result.winner]:.1%}")
        reference = result.source == "reference"
        self.source_badge.setText("参考文件" if reference else "结果文件")
        self.notice.setText("分类值来自参考文件，不是板端测量；频谱由本机根据文件中的 I/Q 计算。" if reference else
                            "分类值来自载入文件；频谱由本机根据对应 I/Q 计算，设备来源按文件记录。")
        self.detail_note.setText("文件得分不等于统计准确率；PC FFT 耗时不代表板端计算耗时。")
        self.export_iq_button.setEnabled(True)
        self.inference_note.setText(f"文件记录的 CNN 推理耗时：{result.inference_ms:.3f} ms" if result.source == "external" and result.inference_ms is not None
                                    else "板端 CNN 推理耗时：未提供")
        for key, (bar, label) in self.score_rows.items():
            bar.setValue(round(result.scores[key]*1000)); label.setText(f"{result.scores[key]:.1%}")
            bar.setStyleSheet("QProgressBar::chunk {background:"+("#0b9c8f" if key == result.winner else "#b4ccd7")+";}")
        self.progress.setValue(100); self.phase.setText("结果已载入"); self.export_button.setEnabled(True)
        record = [datetime.now().strftime("%H:%M:%S"), "参考文件" if result.source == "reference" else "结果文件", CLASS_NAMES[result.winner],
                  f"{result.scores[result.winner]:.1%}", f"{self.fft_ms:.3f}"]
        self.records.append(record); row = self.history.rowCount(); self.history.insertRow(row)
        for col, value in enumerate(record):
            self.history.setItem(row, col, QTableWidgetItem(value))
        if self.history.rowCount() > 100:
            self.history.removeRow(0)
        self.frame_metric.value.setText(f"{len(self.records):02d}")


    def choose_iq(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入裸 I/Q（不是完整 3M 文件）", str(self.base), "信号数据 (*.npz *.bin *.dat)")
        if path:
            try:
                self.set_local_iq(Path(path))
            except (ValueError, OSError, TypeError, KeyError) as exc:
                self.message.emit("I/Q 未导入："+str(exc), "error")

    def set_local_iq(self, path):
        sample = load_iq(path, self.iq_format.currentData(), self.fs.value()*1e6)
        self._clear_result(); self.input_sample = sample; self.analyze(); self.file_path.setText(Path(path).name); self.file_path.setToolTip(str(path))
        self.export_iq_button.setEnabled(True)
        self.source_badge.setText("本地 I/Q · 待分类")
        self.notice.setText("已对文件中的 I/Q 计算 FFT；载入包含得分的 AMC 结果文件可查看分类。")
        self.detail_note.setText("未知输入只分析信号，不根据文件名或星座图形自动生成分类结论。")
        self.process.clear(); self.log("本地 I/Q 已载入，旧分类结论已清除。")

    def choose_result(self, *args):
        path, _ = QFileDialog.getOpenFileName(self, "导入 FFT/AMC 调制识别结果（包含对应 I/Q）", str(self.base/"本地数据文件"/"01_结果数据"), "AMC 结果 (*.bin *.json)")
        if path:
            try:
                self.import_result(Path(path))
            except (ValueError, OSError, TypeError) as exc:
                self.message.emit("分类结果未导入："+str(exc), "error")

    def import_result(self, path):
        result = load_result(path)
        self.display_result(result); self.result_path = path; self.file_path.setText(Path(path).name); self.file_path.setToolTip(str(path))
        self.process.clear(); self.log("已验证 I/Q 数据一致性并导入分类结果："+path.name)
        self.message.emit("AMC 结果已导入："+path.name, "info")

    def choose_export_iq(self):
        if self.input_sample is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出裸 I/Q 样本（还不是平台 DM）", str(self.base/"amc-iq.npz"), "NPZ (*.npz)")
        if path:
            try:
                saved = export_iq(Path(path), self.input_sample)
                self.message.emit("已导出 NPZ、int16 I/Q 和量化说明；需添加平台 Config 后才能作为 DM："+str(saved), "info")
            except (OSError, ValueError) as exc:
                self.message.emit("I/Q 导出失败："+str(exc), "error")

    def toggle_history(self):
        self.history.setVisible(self.history.isHidden())
        self.history_button.setText("收起识别记录" if not self.history.isHidden() else "查看识别记录")

    def export_to(self, path):
        if self.result is None:
            raise ValueError("尚无分类结果可导出")
        path = path.with_suffix(".png")
        if not self.report_image().save(str(path)):
            raise OSError("结果图保存失败")
        save_result(path.with_suffix(".bin"), self.result)
        save_result(path.with_suffix(".json"), self.result)
        return path

    def export_result(self, *args):
        if self.result is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出 AMC 图像与结果数据", str(self.base/"amc-recognition.png"), "PNG (*.png)")
        if path:
            try:
                saved = self.export_to(Path(path)); self.message.emit("AMC 结果图及数据已导出："+saved.name, "info")
            except (OSError, ValueError) as exc:
                self.message.emit("结果导出失败："+str(exc), "error")

    def report_image(self):
        image = QImage(1440, 1010, QImage.Format.Format_RGB32); image.fill(QColor("#f1f6fa")); p = QPainter(image)
        p.fillRect(0, 0, 1440, 118, QColor("#11283e")); p.setPen(QColor("white")); p.setFont(QFont("Microsoft YaHei UI", 23, QFont.Weight.Bold))
        p.drawText(30, 49, APP_TITLE + " / AMC 自动调制识别 · FFT＋CNN")
        p.setFont(QFont("Microsoft YaHei UI", 11)); p.setPen(QColor("#b7cede"))
        mode = "参考文件 / 文件提供的分类值 / 非板端测量" if self.result.source == "reference" else "外部分类结果 / PC 重算频谱 / 设备来源未独立核验"
        p.drawText(31, 80, mode); p.drawText(31, 103, self.input_caption.text())
        x = self.wave_plot.x
        paint_plot(p, QRectF(25, 138, 688, 300), self.wave_plot.title, x, self.wave_plot.traces, None, "时间 ms", "幅值")
        paint_plot(p, QRectF(727, 138, 688, 300), self.spectrum_plot.title, self.spectrum_plot.x, self.spectrum_plot.traces, (-75, 3), "频率 kHz", "相对 dB")
        paint_constellation(p, QRectF(25, 453, 900, 435), self.input_sample)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("white")); p.drawRoundedRect(QRectF(939, 453, 476, 435), 10, 10)
        p.setPen(QColor("#233b52")); p.setFont(QFont("Microsoft YaHei UI", 15, QFont.Weight.Bold)); p.drawText(961, 490, "04  AMC 分类得分")
        p.setFont(QFont("Microsoft YaHei UI", 26, QFont.Weight.Bold)); p.setPen(QColor("#07887c")); p.drawText(962, 546, CLASS_NAMES[self.result.winner])
        p.setFont(QFont("Microsoft YaHei UI", 11))
        for i, key in enumerate(CLASSES):
            y = 585+i*51; p.setPen(QColor("#50677c")); p.drawText(963, y, CLASS_NAMES[key])
            p.drawText(QRectF(1300, y-18, 90, 25), Qt.AlignmentFlag.AlignRight, f"{self.result.scores[key]:.1%}")
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("#e8eff5")); p.drawRoundedRect(QRectF(964, y+10, 420, 9), 4, 4)
            p.setBrush(QColor("#109e8c" if key == self.result.winner else "#b8cfda")); p.drawRoundedRect(QRectF(964, y+10, max(2, 420*self.result.scores[key]), 9), 4, 4)
        p.setPen(QColor("#70869a")); p.setFont(QFont("Microsoft YaHei UI", 10)); p.drawText(962, 835, f"PC FFT 计算耗时：{self.fft_ms:.3f} ms")
        p.drawText(962, 862, "分类得分不等于识别准确率")
        p.drawText(30, 927, "输入 I/Q  →  时域 I/Q ＋ 复数 FFT 特征  →  CNN  →  调制方式与得分")
        p.drawText(30, 958, "频谱以当前样本的最大时频功率为参考；FFT 与 CNN 的板端性能需接入后实测。")
        p.drawText(30, 986, datetime.now().strftime("导出时间  %Y-%m-%d %H:%M:%S")); p.end(); return image

    def stop(self):
        pass

    def clear_display(self):
        self._clear_result(); self.process.clear(); self.log("已清空分类显示，I/Q 和已保存结果保留。")
