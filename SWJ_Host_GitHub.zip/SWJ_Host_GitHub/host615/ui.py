from dataclasses import asdict
from datetime import datetime
import csv
import configparser
import json
from pathlib import Path
import sys
import time

import numpy as np
from PyQt6.QtCore import Qt, QTimer, QUrl, QSize
from PyQt6.QtGui import QColor, QDesktopServices, QFont
from PyQt6.QtNetwork import QAbstractSocket, QNetworkInterface
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QButtonGroup, QComboBox, QDoubleSpinBox,
    QFileDialog, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QScrollArea, QSizePolicy, QSlider, QSpinBox, QStackedWidget,
    QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .branding import APP_TITLE, TEAM_NAME
from .formats import FORMATS, bits_from_file, samples, text_or_binary_wave
from .cnn_ui import AMCPage
from .protocol import ALGORITHMS, MEMORIES, readable_size
from .session import Session, Settings
from .widgets import (Card, CoreGrid, Metric, Plot, initialize_fonts,
                      initialize_theme, navigation_icon, application_icon)


STYLE = """
QWidget { font-family:"Microsoft YaHei UI","Segoe UI"; font-size:12px; color:#23384f; }
QMainWindow, QWidget#content { background:#f3f6fa; }
QFrame#sidebar { background:#11283e; border:0; }
QFrame#sidebar QLabel { color:#abc1d4; background:transparent; }
QFrame#sidebar QLabel#brand { color:white; font-size:28px; font-weight:800; }
QFrame#sidebar QPushButton { background:transparent; color:#b8cbdc; border:0;
    text-align:left; padding:13px 17px; border-radius:9px; font-size:13px; }
QFrame#sidebar QPushButton:checked { color:white; background:#174b5c; font-weight:600; }
QFrame#sidebar QPushButton:hover { background:#203e55; }
QFrame#card { background:white; border:1px solid #e2e9f1; border-radius:13px; }
QLabel#title { font-size:26px; font-weight:700; color:#17324c; }
QLabel#section { font-size:15px; font-weight:700; }
QLabel#muted { color:#718297; }
QLabel#small { color:#8998a9; font-size:10px; }
QLabel#metric { color:#183951; font-size:24px; font-weight:700; }
QLabel#pill { padding:7px 13px; border-radius:13px; background:#e7edf4; color:#74869a; }
QPushButton { background:#fff; border:1px solid #d8e2ed; border-radius:7px;
    padding:8px 13px; color:#3f566b; }
QPushButton:hover { border-color:#38a799; background:#f0faf7; }
QPushButton:pressed { background:#def3ec; }
QPushButton:disabled { color:#a8b5c3; background:#f1f4f8; border-color:#e6ecf2; }
QPushButton#primary { background:#098c80; border-color:#098c80; color:white; font-weight:600; }
QPushButton#primary:hover { background:#087a70; }
QPushButton#primary:disabled { background:#a2cdc5; border-color:#a2cdc5; }
QPushButton#danger { color:#bb5f48; background:#fff8f3; border-color:#f0d7c8; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background:#f8fafc; border:1px solid #dce5ef;
    padding:7px 9px; border-radius:6px; min-height:18px; selection-background-color:#c3eee4; }
QLineEdit:focus, QComboBox:focus { border-color:#2aab9b; }
QComboBox::drop-down { border:0; width:22px; }
QProgressBar { background:#edf2f7; border:0; border-radius:4px; min-height:8px; max-height:8px; }
QProgressBar::chunk { border-radius:4px; background:#15ab93; }
QPlainTextEdit { background:#f8fafc; border:1px solid #e1e8f0; border-radius:9px;
    font-family:"Cascadia Code","Consolas"; font-size:11px; padding:7px; }
QTabWidget::pane { border:1px solid #e2e9f1; background:white; border-radius:8px; }
QTabBar::tab { padding:10px 18px; background:#eaf0f6; border:0; color:#71849a; }
QTabBar::tab:selected { color:#087f74; background:white; }
QTableWidget { background:white; border:1px solid #e1e9f1; border-radius:8px; gridline-color:#edf1f7; }
QHeaderView::section { background:#f0f5f9; padding:10px; border:0; color:#718399; }
QScrollArea { border:0; background:transparent; }
QScrollBar:vertical { background:transparent; width:8px; }
QScrollBar::handle:vertical { background:#c8d5e1; border-radius:4px; min-height:25px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QToolTip { background:#17324c; color:white; padding:6px; border:0; }
"""


def label(text, name=None):
    widget = QLabel(text)
    if name:
        widget.setObjectName(name)
    return widget


def button(text, callback, primary=False):
    widget = QPushButton(text)
    if primary:
        widget.setObjectName("primary")
    widget.clicked.connect(callback)
    return widget


def spin(value, low=1, high=65535):
    widget = QSpinBox()
    widget.setRange(low, high)
    widget.setValue(value)
    return widget


class FileRow(Card):
    def __init__(self, memory, browse, send, handshake):
        super().__init__()
        self.paths = []
        grid = QGridLayout(self)
        grid.setContentsMargins(13, 8, 13, 8)
        grid.setVerticalSpacing(4)
        grid.addWidget(label(memory, "section"), 0, 0)
        self.status = label("尚未选择文件", "muted")
        grid.addWidget(self.status, 0, 1)
        self.browse_button = button("选择文件", browse)
        self.handshake_button = button("握手", handshake)
        self.send_button = button("下发", send)
        for item in (self.browse_button, self.handshake_button, self.send_button):
            item.setStyleSheet("padding:5px 11px;")
        grid.addWidget(self.browse_button, 0, 2)
        grid.addWidget(self.handshake_button, 0, 3)
        grid.addWidget(self.send_button, 0, 4)
        self.path = QLineEdit()
        self.path.setReadOnly(True)
        self.path.setStyleSheet("padding:4px 7px;min-height:14px;font-size:11px;")
        self.path.setPlaceholderText("选择原始 .bin / .dat，可多选并按顺序拼接")
        grid.addWidget(self.path, 1, 0, 1, 5)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setValue(0)
        grid.addWidget(self.progress, 2, 0, 1, 5)
        grid.setColumnStretch(1, 1)

    def set_paths(self, paths):
        self.paths = [Path(p) for p in paths]
        self.path.setText("  +  ".join(p.name for p in self.paths))
        self.path.setToolTip("\n".join(str(p) for p in self.paths))
        total = sum(p.stat().st_size for p in self.paths if p.is_file())
        self.status.setText(f"{len(self.paths)} 个文件 · {readable_size(total)}" if self.paths else "尚未选择文件")
        self.progress.setValue(0)


class MainWindow(QMainWindow):
    def __init__(self, base: Path):
        super().__init__()
        initialize_theme()
        initialize_fonts()
        self.base = base
        self.base.mkdir(parents=True, exist_ok=True)
        self.config_path = base / "settings.json"
        self.session = Session()
        self.session.event.connect(self.on_event)
        self.records = []
        self.last_frame = None
        self._frame_count = 0
        self._rx_bytes = 0
        self._logs = []
        self._startup_time = time.monotonic()
        self._tx_done_at = 0
        self._preview_values = None
        self.result_keys = ("mimo", "cdma", "amc")
        self._hardware_algorithm = "mimo"
        self.result_paths = {}
        self.result_metadata = {}
        self.preview_formats = {key: next(iter(FORMATS)) for key in self.result_keys}
        self._active_result = "mimo"
        self._preview_timer = QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(120)
        self._preview_timer.timeout.connect(self.refresh_preview)
        self.setWindowTitle(APP_TITLE)
        self.setWindowIcon(application_icon())
        self.resize(1420, 960)
        self.setMinimumSize(1100, 740)
        self.setStyleSheet(STYLE)
        root = QWidget()
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.setCentralWidget(root)
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(190)
        nav = QVBoxLayout(sidebar)
        nav.setContentsMargins(19, 28, 19, 22)
        nav.addWidget(label(TEAM_NAME, "brand"))
        nav.addWidget(label("信号处理平台"))
        nav.addSpacing(34)
        self.nav_group = QButtonGroup(self)
        for index, text in enumerate(("工作台", "算法结果", "传输记录", "参数设置")):
            item = QPushButton(text)
            item.setIcon(navigation_icon(index))
            item.setIconSize(QSize(18, 18))
            item.setCheckable(True)
            self.nav_group.addButton(item, index)
            item.clicked.connect(lambda _, i=index: self.pages.setCurrentIndex(i))
            nav.addWidget(item)
        nav.addStretch()
        nav.addWidget(label("路由不迷路团队"))
        nav.addWidget(label("MIMO · CDMA\nAMC · 自动调制识别"))
        nav.addSpacing(18)
        nav.addWidget(button("打开本地数据目录", self.open_local_data))
        nav.addWidget(button("使用说明", self.open_readme))
        outer.addWidget(sidebar)
        content = QWidget()
        content.setObjectName("content")
        body = QVBoxLayout(content)
        body.setContentsMargins(26, 22, 26, 18)
        header = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(3)
        titles.addWidget(label(APP_TITLE, "title"))
        titles.addWidget(label("连接硬件 · 部署算法 · 观察每一帧结果", "muted"))
        header.addLayout(titles)
        header.addStretch()
        self.pill = label("●  未连接", "pill")
        header.addWidget(self.pill)
        body.addLayout(header)
        body.addSpacing(10)
        self.pages = QStackedWidget()
        body.addWidget(self.pages, 1)
        outer.addWidget(content, 1)
        self.make_dashboard()
        self.make_results()
        self.make_history()
        self.make_settings()
        self.pages.currentChanged.connect(lambda _: self.update_actions())
        self.nav_group.button(0).setChecked(True)
        self.statusBar().showMessage("准备就绪 · 先选择本机网卡地址，再连接 FPGA")
        self.refresh_interfaces()
        self.load_config()
        self.format_combo.currentTextChanged.connect(self.schedule_preview)
        self.bit_mode.currentTextChanged.connect(self.schedule_preview)
        self.set_connected(False)
        self.log("欢迎使用路由不迷路信号处理平台。原始文件按字节发送，结果自动保存。")

    def show_page(self, index):
        self.pages.setCurrentIndex(index)
        self.nav_group.button(index).setChecked(True)

    def scroll_page(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        page = QWidget()
        page.setObjectName("content")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 8, 0)
        layout.setSpacing(11)
        scroll.setWidget(page)
        self.pages.addWidget(scroll)
        return layout

    def make_dashboard(self):
        layout = self.scroll_page()
        metrics = QHBoxLayout()
        self.link_metric = Metric("Zynq 通信", "未连接", "UDP / IPv4")
        self.tx_metric = Metric("文件已发送", "0 B", "按 PM → CM → DM 顺序")
        self.rx_metric = Metric("结果已接收", "0 B", "原始数据直接落盘")
        self.frame_metric = Metric("结果帧", "00", "等待完整结果帧")
        for item in (self.link_metric, self.tx_metric, self.rx_metric, self.frame_metric):
            metrics.addWidget(item)
        layout.addLayout(metrics)
        network = Card()
        grid = QGridLayout(network)
        grid.setContentsMargins(17, 11, 17, 11)
        grid.setVerticalSpacing(4)
        grid.addWidget(label("网络连接", "section"), 0, 0)
        grid.addWidget(label("本机 IPv4", "muted"), 1, 0)
        grid.addWidget(label("本机端口", "muted"), 1, 1)
        grid.addWidget(label("Zynq IPv4", "muted"), 1, 2)
        grid.addWidget(label("Zynq 端口", "muted"), 1, 3)
        self.local_ip = QComboBox()
        self.local_ip.setEditable(True)
        self.local_ip.setMinimumWidth(170)
        self.local_port = spin(8080, 0)
        self.local_port.setSpecialValueText("自动分配")
        self.remote_ip = QLineEdit("192.168.1.10")
        self.remote_ip.setMinimumWidth(150)
        self.remote_port = spin(5001)
        for col, widget in enumerate((self.local_ip, self.local_port, self.remote_ip, self.remote_port)):
            grid.addWidget(widget, 2, col)
        self.connect_button = button("连接 FPGA", self.toggle_connection, True)
        grid.addWidget(self.connect_button, 2, 4)
        self.refresh_button = button("刷新本机地址", self.refresh_interfaces)
        grid.addWidget(self.refresh_button, 2, 5)
        self.endpoint_note = label("本平台连接 Zynq 的 UDP 程序；VU13P 的计算状态通过 Zynq 回传。", "small")
        self.endpoint_note.setWordWrap(True)
        grid.addWidget(self.endpoint_note, 3, 0, 1, 6)
        grid.setColumnStretch(0, 2)
        grid.setColumnStretch(2, 2)
        layout.addWidget(network)
        columns = QHBoxLayout()
        upload = Card()
        upload_layout = QVBoxLayout(upload)
        upload_layout.setContentsMargins(16, 12, 16, 12)
        upload_layout.setSpacing(6)
        title = QHBoxLayout()
        title.addWidget(label("算法部署 / 3M 文件", "section"))
        title.addStretch()
        self.algorithm = QComboBox()
        for key, algo in ALGORITHMS.items():
            self.algorithm.addItem(algo.title, key)
        self.algorithm.addItem("AMC 自动调制识别", "amc")
        self.algorithm.currentIndexChanged.connect(self.algorithm_changed)
        title.addWidget(self.algorithm)
        self.apply_algorithm_button = button("应用选择", self.apply_algorithm)
        title.addWidget(self.apply_algorithm_button)
        upload_layout.addLayout(title)
        self.algorithm_note = label("当前算法选择尚未发送到板端", "small")
        self.algorithm_note.setWordWrap(True)
        upload_layout.addWidget(self.algorithm_note)
        hint = label("多选文件按选择顺序拼接；下发前自动握手，文件内容保持原样。", "small")
        upload_layout.addWidget(hint)
        self.file_rows = {}
        for memory in MEMORIES:
            row = FileRow(memory, lambda _, m=memory: self.browse_files(m),
                          lambda _, m=memory: self.upload([m]),
                          lambda _, m=memory: self.manual_handshake(m))
            self.file_rows[memory] = row
            upload_layout.addWidget(row)
        actions = QHBoxLayout()
        actions.addStretch()
        self.cancel_button = button("停止下发", self.session.cancel)
        self.cancel_button.setObjectName("danger")
        actions.addWidget(self.cancel_button)
        self.send_all_button = button("依次下发已选文件  →", lambda: self.upload(list(MEMORIES)), True)
        actions.addWidget(self.send_all_button)
        upload_layout.addLayout(actions)
        self.phase = label("就绪 · 选择文件后开始下发", "muted")
        upload_layout.addWidget(self.phase)
        upload_layout.addStretch()
        columns.addWidget(upload, 3)
        status = Card()
        right = QVBoxLayout(status)
        right.setContentsMargins(16, 12, 16, 12)
        right.setSpacing(4)
        right.addWidget(label("计算平台状态", "section"))
        right.addWidget(label("16 位核状态 · 板端回传", "small"))
        self.core_grid = CoreGrid()
        right.addWidget(self.core_grid)
        self.core_note = label("等待板端状态采样", "muted")
        right.addWidget(self.core_note)
        self.time_note = label("算法耗时计数：—", "muted")
        right.addWidget(self.time_note)
        right.addStretch()
        right.addWidget(label("结果接收", "section"))
        self.rx_progress = QProgressBar()
        self.rx_progress.setTextVisible(False)
        self.rx_progress.setValue(0)
        right.addWidget(self.rx_progress)
        self.rx_note = label("等待结果数据", "small")
        self.rx_note.setWordWrap(True)
        right.addWidget(self.rx_note)
        self.output_button = button("打开结果目录", self.open_output)
        right.addWidget(self.output_button)
        columns.addWidget(status, 1)
        layout.addLayout(columns)
        log_card = Card()
        logs = QVBoxLayout(log_card)
        logs.setContentsMargins(16, 13, 16, 13)
        heading = QHBoxLayout()
        heading.addWidget(label("运行过程", "section"))
        heading.addStretch()
        heading.addWidget(button("导出日志", self.export_logs))
        heading.addWidget(button("清空显示", lambda: self.console.clear()))
        logs.addLayout(heading)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(600)
        self.console.setFixedHeight(76)
        logs.addWidget(self.console)
        layout.addWidget(log_card)
        layout.addStretch()

    def make_results(self):
        layout = self.scroll_page()
        card = Card()
        self.result_tools_card = card
        tools = QVBoxLayout(card)
        row = QHBoxLayout()
        row.addWidget(label("算法结果", "section"))
        row.addStretch()
        row.addWidget(button("载入本地结果", self.load_result))
        row.addWidget(button("载入本地波形", self.load_wave))
        row.addWidget(button("导出当前图像", self.export_plot))
        tools.addLayout(row)
        self.result_path = QLineEdit()
        self.result_path.setReadOnly(True)
        self.result_path.setPlaceholderText("完成一帧接收后自动展示，也可载入 .bin / .dat 文件")
        tools.addWidget(self.result_path)
        row = QHBoxLayout()
        row.addWidget(label("数据解释"))
        self.format_combo = QComboBox()
        self.format_combo.addItems(FORMATS)
        row.addWidget(self.format_combo)
        row.addWidget(button("重新绘制", self.refresh_preview, True))
        row.addStretch()
        tools.addLayout(row)
        self.preview_note = label("原始文件始终保留，预览格式可调整。", "small")
        self.preview_note.setWordWrap(True)
        tools.addWidget(self.preview_note)
        layout.addWidget(card)
        self.result_tabs = QTabWidget()
        mimo = QWidget()
        plots = QVBoxLayout(mimo)
        row = QHBoxLayout()
        self.scatter = Plot("I / Q 星座图")
        self.spectrum = Plot("接收样点频谱 · 相对 dB", "#5675c9")
        row.addWidget(self.scatter)
        row.addWidget(self.spectrum)
        plots.addLayout(row)
        self.wave = Plot("接收样点 / 本地波形")
        plots.addWidget(self.wave)
        self.result_tabs.addTab(mimo, "MIMO / 波形")
        cdma = QWidget()
        bits = QVBoxLayout(cdma)
        row = QHBoxLayout()
        self.bit_mode = QComboBox()
        self.bit_mode.addItems(["自动识别", "int16 数值 0/1", "uint8 数值 0/1", "逐字节展开比特"])
        row.addWidget(self.bit_mode)
        self.reference_bits = QLineEdit()
        self.reference_bits.setPlaceholderText("选择参考比特文件后计算实际误码率")
        row.addWidget(self.reference_bits, 1)
        row.addWidget(button("参考比特", self.choose_reference_bits))
        row.addWidget(button("计算", self.refresh_bits, True))
        bits.addLayout(row)
        self.bit_plot = Plot("接收比特 · 前 512 位")
        bits.addWidget(self.bit_plot)
        self.ber_note = label("尚未载入参考比特，不显示误码率。", "muted")
        self.ber_note.setWordWrap(True)
        bits.addWidget(self.ber_note)
        self.result_tabs.addTab(cdma, "CDMA / 误码分析")
        self.amc_page = AMCPage(self.base)
        self.amc_page.message.connect(self.log)
        self.result_tabs.addTab(self.amc_page, "AMC / 自动调制识别")
        self.result_tabs.currentChanged.connect(self.result_tab_changed)
        layout.addWidget(self.result_tabs)
        layout.addStretch()

    def make_history(self):
        layout = self.scroll_page()
        title = QHBoxLayout()
        title.addWidget(label("结果接收记录", "section"))
        title.addStretch()
        title.addWidget(button("打开选中文件目录", self.open_selected_record))
        title.addWidget(button("导出 CSV", self.export_history))
        layout.addLayout(title)
        self.history = QTableWidget(0, 7)
        self.history.setHorizontalHeaderLabels(["接收时间", "算法", "实际字节", "预期字节", "状态", "UDP 包", "文件"])
        self.history.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.history.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self.history.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.history.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history.setMinimumHeight(470)
        self.history.doubleClicked.connect(lambda _: self.preview_selected_record())
        layout.addWidget(self.history)
        layout.addWidget(label("双击记录预览。长度不符或中途断开的帧保留为 .partial.bin；旁边 JSON 保存长度、包数和 SHA256。", "muted"))

    def make_settings(self):
        layout = self.scroll_page()
        card = Card()
        form = QFormLayout(card)
        form.setContentsMargins(24, 20, 24, 20)
        form.setSpacing(13)
        self.output_dir = QLineEdit(str(self.base / "results"))
        row = QHBoxLayout()
        row.addWidget(self.output_dir)
        row.addWidget(button("选择目录", self.choose_output))
        form.addRow("结果保存位置", row)
        self.rate = spin(1024, 16, 65536)
        self.rate.setSuffix(" KiB/s")
        form.addRow("下发速率", self.rate)
        self.chunk = spin(1024, 16, 1400)
        self.chunk.setSuffix(" B")
        form.addRow("UDP 文件数据块", self.chunk)
        self.gap = spin(800, 100, 30000)
        self.gap.setSuffix(" ms")
        form.addRow("文件间处理间隔", self.gap)
        self.timeout = spin(1000, 100, 10000)
        self.timeout.setSuffix(" ms")
        form.addRow("握手应答超时", self.timeout)
        self.expected = spin(65024, 1, 1024 * 1024 * 512)
        self.expected.setSuffix(" B")
        form.addRow("每帧预期结果长度", self.expected)
        self.counter_us = QDoubleSpinBox()
        self.counter_us.setRange(0, 1000000)
        self.counter_us.setDecimals(4)
        self.counter_us.setSuffix(" μs / 计数")
        form.addRow("硬件计数单位，0 表示未知", self.counter_us)
        self.source_dir = QLineEdit(str(Path.home() / "Desktop/615_1/Display/Display"))
        row = QHBoxLayout()
        row.addWidget(self.source_dir)
        row.addWidget(button("选择工程目录", self.choose_source))
        form.addRow("原 Display/Display 目录", row)
        form.addRow(button("导入原上位机 para_setting.ini", self.import_legacy))
        form.addRow(button("保存设置", self.save_config, True))
        layout.addWidget(card)
        info = Card()
        text = QVBoxLayout(info)
        text.setContentsMargins(22, 18, 22, 18)
        text.addWidget(label("与现有固件保持一致", "section"))
        note = label(
            "• 协议依据为现有 udp_ddr3 固件；FACE 厂商测试工程只作硬件参考。\n"
            "• 本机 IPv4 从网卡读取；Zynq 地址采用原工程默认值，可手动修改。固件不提供自动发现接口。\n"
            "• hello 回显只确认 Zynq 的 UDP 程序应答；核状态、算法计数和结果分别以实际回传为准。\n"
            "• 下发进度表示本机已发送字节；固件没有逐包 ACK，不能据此证明板端已完整收到文件。\n"
            "• FPGA 单次 / 连续 / 停止运行，仍按原说明通过 Vivado VIO 的 switch_type 控制。\n"
            "• 当前协议没有远程硬件复位命令。中止文件后，请重启 Zynq 通信程序，避免残留计数影响下一次下发。\n"
            "• MIMO 默认按交替 int16 I/Q 预览；具体输出格式可在结果页调整，原始文件不会修改。\n"
            "• 本地文件与设备接收数据分别标注来源；AMC 需要文件中包含识别结果才能显示分类。", "muted")
        note.setWordWrap(True)
        text.addWidget(note)
        actions = QHBoxLayout()
        actions.addWidget(button("复位上位机显示", self.reset_view))
        actions.addWidget(button("已重启板端通信，解除中止保护", self.clear_abort_guard))
        text.addLayout(actions)
        layout.addWidget(info)
        layout.addStretch()

    def guarded(self, action):
        try:
            return action()
        except Exception as exc:
            self.log(str(exc), "error")
            QMessageBox.warning(self, "操作未完成", str(exc))
            return None

    def refresh_interfaces(self):
        old = self.local_ip.currentText().strip()
        addresses = []
        for interface in QNetworkInterface.allInterfaces():
            if not interface.flags() & QNetworkInterface.InterfaceFlag.IsUp:
                continue
            for entry in interface.addressEntries():
                ip = entry.ip()
                if ip.protocol() == QAbstractSocket.NetworkLayerProtocol.IPv4Protocol:
                    addresses.append((ip.toString(), interface.humanReadableName()))
        self.local_ip.clear()
        for ip, name in addresses:
            self.local_ip.addItem(ip)
            self.local_ip.setItemData(self.local_ip.count() - 1, name, Qt.ItemDataRole.ToolTipRole)
        if old:
            self.local_ip.setCurrentText(old)
        elif any(ip == "192.168.1.11" for ip, _ in addresses):
            self.local_ip.setCurrentText("192.168.1.11")
        else:
            preferred = next((ip for ip, _ in addresses if not ip.startswith("127.")), "127.0.0.1")
            self.local_ip.setCurrentText(preferred)

    def current_settings(self):
        return Settings(local_ip=self.local_ip.currentText().strip(),
                        local_port=self.local_port.value(), remote_ip=self.remote_ip.text().strip(),
                        remote_port=self.remote_port.value(), algorithm=self.hardware_algorithm(),
                        rate_kib=self.rate.value(), chunk_size=self.chunk.value(),
                        file_gap_ms=self.gap.value(), handshake_ms=self.timeout.value(),
                        output_dir=self.output_dir.text().strip(), expected_bytes=self.expected.value())

    def hardware_algorithm(self):
        key = self.algorithm.currentData()
        return key if key in ALGORITHMS else self._hardware_algorithm

    def toggle_connection(self):
        if self.session.sock:
            self.session.close()
            self.set_connected(False)
            self.log("UDP 端口已关闭")
        else:
            self.guarded(lambda: self.session.open(self.current_settings()))
            if self.session.sock:
                self.save_config()

    def set_connected(self, connected):
        self.connect_button.setText("断开连接" if connected else "连接 FPGA")
        for widget in (self.local_ip, self.local_port, self.remote_ip, self.remote_port,
                       self.rate, self.chunk, self.gap, self.timeout, self.output_dir, self.expected):
            widget.setEnabled(not connected)
        self.update_actions()

    def update_actions(self):
        amc = self.algorithm.currentData() == "amc"
        ready = self.session.verified and not self.session.busy and not self.session.needs_board_reset and not amc
        self.send_all_button.setEnabled(ready)
        self.cancel_button.setEnabled(self.session.busy)
        self.algorithm.setEnabled(not self.session.busy)
        self.apply_algorithm_button.setEnabled(not self.session.busy)
        for row in self.file_rows.values():
            row.send_button.setEnabled(ready)
            row.handshake_button.setEnabled(bool(self.session.sock) and not self.session.busy and not amc)
            row.browse_button.setEnabled(not self.session.busy and not amc)

    def algorithm_changed(self):
        key = self.algorithm.currentData()
        if key in ALGORITHMS:
            self._hardware_algorithm = key
        if hasattr(self, "expected") and key in ALGORITHMS:
            self.expected.setValue(ALGORITHMS[key].result_bytes)
        if hasattr(self, "algorithm_note"):
            self.algorithm_note.setText("AMC：本地文件分析与结果导入；板端通道待接入" if key == "amc" else
                                        "当前算法选择尚未发送到板端")
        if hasattr(self, "amc_page"):
            if key == "amc":
                self.result_tabs.setCurrentIndex(self.result_keys.index("amc"))
                self.show_page(1)
            self.update_actions()

    def apply_algorithm(self):
        def action():
            key = self.algorithm.currentData()
            if key == "amc":
                self.result_tabs.setCurrentIndex(self.result_keys.index("amc"))
                self.show_page(1)
                self.log("已打开 AMC；载入 I/Q 可分析信号，载入结果文件可查看分类")
                return
            self.session.set_algorithm(key, self.expected.value())
            if not self.session.sock:
                self.log(f"已选择 {ALGORITHMS[key].title}，连接后下发时应用")
        self.guarded(action)

    def browse_files(self, memory):
        paths, _ = QFileDialog.getOpenFileNames(self, f"选择 {memory} 文件，按下发顺序多选",
                                                self.source_dir.text(), "数据文件 (*.bin *.dat *.txt);;所有文件 (*)")
        if paths:
            self.file_rows[memory].set_paths(paths)
            self.save_config()

    def upload(self, memories):
        if self.algorithm.currentData() == "amc":
            self.log("AMC 板端协议与程序待接入，请在 AMC 页面载入本地数据或结果文件", "warning")
            return
        def action():
            self.session.set_algorithm(self.algorithm.currentData(), self.expected.value(), send_command=False)
            self.session.upload([(m, self.file_rows[m].paths) for m in memories])
            self.update_actions()
        self.guarded(action)

    def manual_handshake(self, memory):
        if self.algorithm.currentData() == "amc":
            return
        self.guarded(lambda: self.session.probe(memory))
        self.update_actions()


    def on_event(self, event):
        kind = event["kind"]
        if kind == "log":
            self.log(event["text"], event.get("level", "info"))
        elif kind == "link":
            state = event["state"]
            names = {"bound": "端口已绑定", "probing": "等待 UDP 应答",
                     "verified": "UDP 已响应", "unverified": "UDP 应答未确认", "closed": "未连接"}
            self.pill.setText("●  " + names[state])
            self.pill.setStyleSheet("background:#dcf5ec;color:#087a65;" if state == "verified" else "")
            self.link_metric.value.setText("Zynq UDP 应答"
                                           if state == "verified" else names[state])
            self.link_metric.note.setText(datetime.now().strftime("最近确认 %H:%M:%S") if state == "verified" else "UDP / IPv4")
            if state == "verified":
                self.endpoint_note.setText("已收到 Zynq 的 hello 回显；计算平台状态与结果分别以右侧实际回传为准。")
            elif state == "unverified":
                self.endpoint_note.setText("本次 UDP 应答未确认；请检查本机网卡、Zynq 程序和网线，可再次握手。")
            elif state == "closed":
                self.endpoint_note.setText("本平台连接 Zynq 的 UDP 程序；VU13P 的计算状态通过 Zynq 回传。")
            else:
                self.endpoint_note.setText("正在确认 UDP 通信程序是否应答；hello 不检查 VU13P 的计算功能。")
            if state in ("bound", "closed"):
                self.clear_telemetry()
                self.algorithm_note.setText("当前算法选择尚未发送到板端")
            if state == "bound":
                self.local_port.setValue(self.session.settings.local_port)
            self.set_connected(state != "closed")
        elif kind == "algorithm":
            text = ALGORITHMS[event["key"]].title
            self.algorithm_note.setText(f"{text}：命令已发送；当前固件无算法确认应答"
                                        if event["command_sent"] else f"{text}：当前选择尚未发送到板端")
        elif kind == "tx_progress":
            sent, total = event["sent"], event["total"]
            self.file_rows[event["memory"]].progress.setValue(min(100, int(sent * 100 / max(1, total))))
            self.file_rows[event["memory"]].status.setText(f"{readable_size(sent)} / {readable_size(total)}")
            self.tx_metric.value.setText(readable_size(event["overall"]))
            speed = event["overall"] / max(.01, event["seconds"])
            self.tx_metric.note.setText(f"{readable_size(speed)}/s · 本机发送进度")
        elif kind == "phase":
            self.phase.setText(event["text"])
        elif kind == "memory_sent":
            self.file_rows[event["memory"]].status.setText(f"本机已发送 · {readable_size(event['bytes'])}")
        elif kind == "upload_done":
            self.log(f"本轮下发结束：{readable_size(event['bytes'])}，耗时 {event['seconds']:.2f} s")
        elif kind == "rx_progress":
            self._rx_bytes = event["total_rx"]
            self.rx_metric.value.setText(readable_size(self._rx_bytes))
            self.rx_progress.setValue(min(99, int(event["received"] * 100 / event["expected"])))
            self.rx_note.setText(f"{readable_size(event['received'])} / {readable_size(event['expected'])} · {event['packets']} 包")
        elif kind == "telemetry":
            self.telemetry(event["name"], event["value"])
        elif kind == "frame":
            self.record_frame(event)
        elif kind == "operation_error":
            self.phase.setText("操作未完成 · " + event["text"])
        elif kind == "reset_required":
            self.phase.setText("文件中途终止 · 需重启板端通信后重新握手")
        elif kind == "task_done":
            QTimer.singleShot(40, self.update_actions)

    def clear_telemetry(self):
        self.core_grid.mask = 0
        self.core_grid.observed = False
        self.core_grid.update()
        self.core_note.setText("等待板端状态采样")
        self.time_note.setText("算法耗时计数：—")

    def telemetry(self, name, value):
        if name in ("cores", "cores_finished"):
            self.core_grid.set_mask(value)
            self.core_note.setText(f"{int(value).bit_count():02d} / 16 核运行 · 0x{value:04X}")
            if name == "cores_finished":
                self.core_note.setText("核状态已回到空闲；结果接收状态另见下方")
        elif name == "algorithm_time":
            self.time_note.setText("算法耗时：" + self.format_counter(value))
            self.log(f"算法耗时回传：原始计数 {value}")

    def format_counter(self, value):
        unit = self.counter_us.value()
        return f"{value * unit:.3f} μs" if unit else f"{value:,} 计数"

    def record_frame(self, result):
        self._frame_count += 1
        self.frame_metric.value.setText(f"{self._frame_count:02d}")
        self.frame_metric.note.setText("已结束且长度匹配" if result["complete"] else "包含不完整帧")
        self.rx_progress.setValue(100 if result["complete"] else min(99, int(result["bytes"] * 100 / result["expected_bytes"])))
        self.rx_note.setText(f"{'收到结束标记，长度符合预期' if result['complete'] else '不完整帧，已保留'} · {readable_size(result['bytes'])}")
        self._rx_bytes = self.session.total_rx
        self.rx_metric.value.setText(readable_size(self._rx_bytes))
        self.last_frame = result
        self.records.append(result)
        row = self.history.rowCount()
        self.history.insertRow(row)
        values = [result["timestamp"], ALGORITHMS[result["algorithm"]].title, str(result["bytes"]),
                  str(result["expected_bytes"]), "长度匹配" if result["complete"] else "不完整",
                  str(result["packets"]), Path(result["path"]).name]
        for col, value in enumerate(values):
            item = QTableWidgetItem(value)
            item.setToolTip(result["path"] if col == 6 else value)
            if col == 4:
                item.setForeground(QColor("#098b70" if result["complete"] else "#c57838"))
            self.history.setItem(row, col, item)
        self.log(f"结果帧{'已结束且长度符合预期' if result['complete'] else '不完整，已保留'}：{result['bytes']:,} / "
                 f"{result['expected_bytes']:,} B → {Path(result['path']).name}",
                 "info" if result["complete"] else "warning")
        self.show_result_file(result["path"])
        self.result_paths[result["algorithm"]] = result["path"]
        self.result_metadata[result["algorithm"]] = result
        target = self.result_keys.index(result["algorithm"])
        self.result_tabs.setCurrentIndex(target)
        self.refresh_preview()

    def result_tab_changed(self, index):
        if self._active_result != "amc":
            self.preview_formats[self._active_result] = self.format_combo.currentText()
        self._active_result = self.result_keys[index]
        self.result_tools_card.setVisible(self._active_result != "amc")
        if self.result_keys[index] == "amc":
            self._preview_timer.stop()
            self.update_actions()
            return
        self.format_combo.blockSignals(True)
        self.format_combo.setCurrentText(self.preview_formats[self._active_result])
        self.format_combo.blockSignals(False)
        self.show_result_file(self.result_paths.get(self._active_result, ""))
        self.refresh_preview()
        self.update_actions()

    def schedule_preview(self, *args):
        self._preview_timer.start()

    def show_empty_result(self):
        key = self.result_keys[self.result_tabs.currentIndex()]
        if key == "amc":
            return
        title = ALGORITHMS[key].title
        self.preview_note.setText(f"尚无 {title} 结果。请载入对应结果文件，或连接设备接收数据。")
        if key == "cdma":
            self.bit_plot.clear()
            self.ber_note.setText("尚无 CDMA 比特数据")
        else:
            for plot in (self.scatter, self.spectrum, self.wave):
                plot.clear()

    def load_result(self):
        if self.result_keys[self.result_tabs.currentIndex()] == "amc":
            self.amc_page.choose_result()
            return
        path, _ = QFileDialog.getOpenFileName(self, "载入结果数据", str(self.base / "本地数据文件" / "01_结果数据"),
                                              "结果数据 (*.bin *.dat);;所有文件 (*)")
        if path:
            self.guarded(lambda: self.load_local_result(Path(path)))

    def open_local_data(self):
        folder = self.base / "本地数据文件"
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder if folder.is_dir() else self.base)))

    def load_local_result(self, path):
        path = Path(path)
        with path.open("rb") as stream:
            magic = stream.read(8)
        if magic == b"615AMC1\0":
            self.amc_page.import_result(path)
            self.result_tabs.setCurrentIndex(self.result_keys.index("amc"))
            self.show_page(1)
            return
        key = self.result_keys[self.result_tabs.currentIndex()]
        meta = {}
        try:
            meta = json.loads(path.with_suffix(".json").read_text(encoding="utf8"))
        except (OSError, ValueError):
            pass
        if not isinstance(meta, dict):
            meta = {}
        declared = meta.get("algorithm")
        if declared and declared not in ALGORITHMS:
            raise ValueError("文件所属算法不在当前支持列表中")
        key = declared or key
        if key == "amc":
            self.amc_page.import_result(path)
            return
        fmt = meta.get("preview_format")
        if fmt in FORMATS:
            self.preview_formats[key] = fmt
        self.result_paths[key] = str(path)
        self.result_metadata[key] = meta
        self.result_tabs.setCurrentIndex(self.result_keys.index(key))
        self.format_combo.blockSignals(True)
        self.format_combo.setCurrentText(self.preview_formats[key])
        self.format_combo.blockSignals(False)
        self.show_result_file(path)
        self.refresh_preview()
        self.show_page(1)

    def show_result_file(self, path):
        self.result_path.setText(Path(path).name if path else "")
        self.result_path.setToolTip(str(path))

    def refresh_preview(self):
        key = self.result_keys[self.result_tabs.currentIndex()]
        if key == "amc":
            return
        self.format_combo.setEnabled(key == "mimo")
        path = self.result_paths.get(key, "")
        if not path or not Path(path).is_file():
            self.show_empty_result()
            return
        try:
            if key == "cdma":
                self.refresh_bits()
                return
            values = samples(path, self.format_combo.currentText())
            if not len(values):
                raise ValueError("文件没有可显示的样点")
            self._preview_values = values
            self.scatter.set_data(values.real, values.imag if np.iscomplexobj(values) else np.zeros(len(values)), True)
            count = min(len(values), 8192)
            transform = np.fft.fftshift(np.fft.fft(values[:count] * np.hanning(count)))
            spectrum = 20 * np.log10(np.maximum(np.abs(transform), 1e-12))
            spectrum -= spectrum.max()
            self.spectrum.set_data(np.linspace(-.5, .5, count, endpoint=False), spectrum)
            self.wave.set_data(np.arange(min(2048, len(values))), values.real[:2048])
            self.preview_formats[key] = self.format_combo.currentText()
            complete = self.result_metadata.get(key, {}).get("complete")
            status = "不完整帧 · " if complete is False else ""
            prefix = "参考文件 · " if self.result_metadata.get(key, {}).get("source") == "reference" else ""
            self.preview_note.setText(f"{prefix}{status}{Path(path).name} · {Path(path).stat().st_size:,} B · {len(values):,} 样点 · {self.format_combo.currentText()}")
        except Exception as exc:
            self.preview_note.setText(f"文件已保存；当前预览设置无法解释此数据：{exc}")
            for plot in (self.scatter, self.spectrum, self.wave):
                plot.clear()

    def load_wave(self):
        path, _ = QFileDialog.getOpenFileName(self, "载入本地波形", self.source_dir.text(),
                                              "数据 (*.dat *.txt *.bin);;所有文件 (*)")
        if not path:
            return
        try:
            values = text_or_binary_wave(path)
            self.result_tabs.setCurrentIndex(0)
            self.wave.set_data(np.arange(len(values)), values)
            self.preview_note.setText(f"本地波形：{path} · {len(values):,} 样点")
        except Exception as exc:
            self.log(str(exc), "error")


    def choose_reference_bits(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择参考比特", self.source_dir.text(), "所有文件 (*)")
        if path:
            self.reference_bits.setText(path)
            self.refresh_bits()

    def refresh_bits(self):
        path = self.result_paths.get("cdma", "")
        if not path:
            self.show_empty_result()
            return
        try:
            received = bits_from_file(path, self.bit_mode.currentText())
            prefix = "参考文件 · " if self.result_metadata.get("cdma", {}).get("source") == "reference" else ""
            self.preview_note.setText(f"{prefix}{Path(path).name} · {len(received):,} 位 · {self.bit_mode.currentText()}")
            self.bit_plot.set_data(np.arange(min(512, len(received))), received[:512])
            if not self.reference_bits.text():
                self.ber_note.setText(f"已读取 {len(received):,} 位；载入参考比特后可计算误码率。")
                return
            reference = bits_from_file(self.reference_bits.text(), self.bit_mode.currentText())
            n = min(len(received), len(reference))
            if n == 0:
                raise ValueError("比特文件为空")
            errors = int(np.count_nonzero(received[:n] != reference[:n]))
            self.ber_note.setText(f"前 {n:,} 位比较：误码 {errors:,} 位 / BER {errors / n:.6%}。"
                                  f"接收 {len(received):,} 位，参考 {len(reference):,} 位。")
        except Exception as exc:
            self.ber_note.setText(f"无法计算：{exc}")
            self.bit_plot.clear()

    def export_plot(self):
        key = self.result_keys[self.result_tabs.currentIndex()]
        if key == "amc":
            self.amc_page.export_result()
            return
        widget = self.scatter if key == "mimo" else self.bit_plot
        path, _ = QFileDialog.getSaveFileName(self, "导出图像", str(self.base / "results/preview.png"), "PNG (*.png)")
        if path:
            widget.grab().save(path)
            self.log(f"图像已导出：{Path(path).name}")

    def preview_selected_record(self):
        row = self.history.currentRow()
        if row >= 0:
            record = self.records[row]
            self.result_paths[record["algorithm"]] = record["path"]
            self.result_metadata[record["algorithm"]] = record
            self.show_result_file(record["path"])
            self.result_tabs.setCurrentIndex(self.result_keys.index(record["algorithm"]))
            self.refresh_preview()
            self.show_page(1)

    def open_selected_record(self):
        row = self.history.currentRow()
        if row >= 0:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.records[row]["path"]).parent)))

    def log(self, text, level="info"):
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        entry = {"time": now, "level": level, "message": text}
        self._logs.append(entry)
        self.console.appendPlainText(f"{now[11:19]}  {level.upper():7}  {text}")
        self.statusBar().showMessage(text)
        try:
            folder = self.base / "logs"
            folder.mkdir(exist_ok=True)
            with (folder / f"host_{now[:10]}.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            pass

    def export_logs(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出日志", str(self.base / "logs/session.jsonl"),
                                              "JSON Lines (*.jsonl)")
        if path:
            Path(path).write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in self._logs), encoding="utf-8")

    def export_history(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出记录", str(self.base / "results/history.csv"), "CSV (*.csv)")
        if path:
            with open(path, "w", newline="", encoding="utf-8-sig") as stream:
                writer = csv.DictWriter(stream, fieldnames=["timestamp", "algorithm", "bytes", "expected_bytes",
                                                            "complete", "packets", "seconds", "path", "sha256"],
                                        extrasaction="ignore")
                writer.writeheader()
                writer.writerows(self.records)

    def choose_output(self):
        path = QFileDialog.getExistingDirectory(self, "选择结果目录", self.output_dir.text())
        if path:
            self.output_dir.setText(path)

    def choose_source(self):
        path = QFileDialog.getExistingDirectory(self, "选择包含 03TEST_data 的目录", self.source_dir.text())
        if path:
            self.source_dir.setText(path)

    def import_legacy(self):
        if self.session.sock:
            self.log("请先断开连接，再导入原参数", "warning")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "选择原上位机配置", str(Path(self.source_dir.text()) / "04swj0813"),
            "INI 配置 (*.ini)")
        if not path:
            return
        try:
            parser = configparser.ConfigParser(interpolation=None)
            parser.read(path, encoding="utf-8-sig")
            config = parser["General"]
            self.local_ip.setCurrentText(config.get("IP4Src", "192.168.1.11"))
            self.local_port.setValue(config.getint("Port4Src", 8080))
            self.remote_ip.setText(config.get("IP4Dest", "192.168.1.10"))
            self.remote_port.setValue(config.getint("Port4Dest", 5001))
            self.current_settings().validate()
            self.save_config()
            self.log("原上位机的本机/目标 IPv4 和端口已导入，尚未连接")
        except (ValueError, KeyError, OSError, configparser.Error) as exc:
            self.log(f"配置导入失败：{exc}", "error")

    def open_output(self):
        path = Path(self.output_dir.text())
        path.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def open_readme(self):
        path = self.base / "README.md"
        if not path.is_file():
            path = Path(getattr(sys, "_MEIPASS", self.base)) / "README.md"
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def reset_view(self):
        if self.session.busy or self.session._frame:
            self.log("请先停止下发，并等待当前结果帧结束后再清空显示", "warning")
            return
        for row in self.file_rows.values():
            row.progress.setValue(0)
        self.amc_page.clear_display()
        self.clear_telemetry()
        self.rx_progress.setValue(0)
        self.result_paths.clear()
        self.result_metadata.clear()
        self.result_path.clear()
        self.preview_note.setText("原始结果文件保留，可从传输记录重新预览。")
        self.phase.setText("上位机显示已复位；硬件运行状态保持原样")
        for plot in (self.scatter, self.spectrum, self.wave, self.bit_plot):
            plot.clear()
        self.log("已复位上位机显示，保存的结果文件保留")

    def clear_abort_guard(self):
        if self.session.sock:
            self.session.close()
        self.guarded(self.session.acknowledge_board_reset)
        self.set_connected(False)

    def config_snapshot(self):
        return {"network": asdict(self.current_settings()), "counter_us": self.counter_us.value(),
                 "source_dir": self.source_dir.text(),
                 "files": {m: [str(p) for p in row.paths] for m, row in self.file_rows.items()}}

    def save_config(self):
        value = self.config_snapshot()
        value["preview"] = {"formats": {**self.preview_formats, self._active_result: self.format_combo.currentText()},
                            "bit_mode": self.bit_mode.currentText()}
        try:
            temp = self.config_path.with_suffix(".tmp")
            temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(self.config_path)
        except OSError as exc:
            self.log(f"设置保存失败：{exc}", "error")

    def load_config(self):
        if not self.config_path.is_file():
            return
        try:
            value = json.loads(self.config_path.read_text(encoding="utf-8"))
            net = value.get("network", {})
            if net.get("remote_ip") == "127.0.0.1" and "simulation" in net.get("output_dir", ""):
                value["network"] = asdict(Settings(local_ip=self.local_ip.currentText(),
                                                   output_dir=str(self.base / "results")))
                value["files"] = {}
                self.log("旧设置指向临时本机地址，已恢复默认设备配置；原文件保留", "warning")
            self.apply_config(value)
            preview = value.get("preview", {})
            for key, fmt in preview.get("formats", {}).items():
                if key in self.preview_formats and fmt in FORMATS:
                    self.preview_formats[key] = fmt
            self.format_combo.setCurrentText(self.preview_formats[self._active_result])
            self.bit_mode.setCurrentText(preview.get("bit_mode", "自动识别"))
        except (ValueError, TypeError, OSError, KeyError):
            self.log("原设置无法读取，已使用默认值", "warning")

    def apply_config(self, value):
        settings = Settings(**value.get("network", {}))
        supported = settings.algorithm in ALGORITHMS
        if not supported:
            settings.algorithm = "mimo"
            settings.expected_bytes = ALGORITHMS["mimo"].result_bytes
            self.log("旧设置中的算法已停用：改为 MIMO，清空文件选择，请载入匹配文件后再下发", "warning")
        self.local_ip.setCurrentText(settings.local_ip)
        self.local_port.setValue(settings.local_port)
        self.remote_ip.setText(settings.remote_ip)
        self.remote_port.setValue(settings.remote_port)
        self.algorithm.setCurrentIndex(list(ALGORITHMS).index(settings.algorithm))
        self.rate.setValue(settings.rate_kib)
        self.chunk.setValue(settings.chunk_size)
        self.gap.setValue(settings.file_gap_ms)
        self.timeout.setValue(settings.handshake_ms)
        self.output_dir.setText(settings.output_dir)
        self.expected.setValue(settings.expected_bytes)
        self.counter_us.setValue(value.get("counter_us", 0))
        self.source_dir.setText(value.get("source_dir", self.source_dir.text()))
        file_choices = value.get("files", {}) if supported else {}
        for memory, row in self.file_rows.items():
            row.set_paths([p for p in file_choices.get(memory, []) if Path(p).is_file()])

    def closeEvent(self, event):
        self.amc_page.stop()
        self._preview_timer.stop()
        self.save_config()
        self.session.close()
        event.accept()
