from collections import deque
import os
from pathlib import Path
import numpy as np
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtGui import QColor, QFont, QFontDatabase, QIcon, QImage, QPainter, QPalette, QPen, QPixmap, QPolygonF
from PyQt6.QtWidgets import QApplication, QFrame, QLabel, QSizePolicy, QVBoxLayout, QWidget

_fonts_loaded = False


def initialize_theme():
    """Keep the designed light UI consistent with Windows dark-mode settings."""
    app = QApplication.instance()
    app.setStyle("Fusion")
    palette = QPalette()
    for role, color in (
        (QPalette.ColorRole.Window, "#f3f6fa"),
        (QPalette.ColorRole.WindowText, "#23384f"),
        (QPalette.ColorRole.Base, "#ffffff"),
        (QPalette.ColorRole.AlternateBase, "#f0f5f9"),
        (QPalette.ColorRole.Text, "#23384f"),
        (QPalette.ColorRole.Button, "#ffffff"),
        (QPalette.ColorRole.ButtonText, "#23384f"),
        (QPalette.ColorRole.Highlight, "#098c80"),
        (QPalette.ColorRole.HighlightedText, "#ffffff"),
    ):
        palette.setColor(role, QColor(color))
    app.setPalette(palette)


def initialize_fonts():
    """Offscreen Qt on Windows has no default font database; load installed fonts."""
    global _fonts_loaded
    if _fonts_loaded:
        return
    fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for name in ("msyh.ttc", "msyhbd.ttc", "segoeui.ttf", "segoeuib.ttf",
                 "seguisym.ttf", "consola.ttf"):
        path = fonts / name
        if path.is_file():
            QFontDatabase.addApplicationFont(str(path))
    _fonts_loaded = True


def navigation_icon(index):
    pixmap = QPixmap(24, 24)
    pixmap.fill(Qt.GlobalColor.transparent)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor("#bad4e2"), 1.6))
    if index == 0:
        for x, y in ((4, 4), (14, 4), (4, 14), (14, 14)):
            p.drawRoundedRect(QRectF(x, y, 6, 6), 1, 1)
    elif index == 1:
        p.drawLine(4, 20, 4, 4)
        p.drawLine(4, 20, 21, 20)
        p.drawPolyline(QPolygonF([QPointF(6, 15), QPointF(11, 9), QPointF(15, 12), QPointF(21, 5)]))
    elif index == 2:
        p.drawRoundedRect(QRectF(5, 3, 14, 18), 2, 2)
        for y in (8, 12, 16):
            p.drawLine(8, y, 16, y)
    else:
        p.drawEllipse(QPointF(12, 12), 7, 7)
        p.drawEllipse(QPointF(12, 12), 2.5, 2.5)
        for x1, y1, x2, y2 in ((12, 2, 12, 5), (12, 19, 12, 22), (2, 12, 5, 12), (19, 12, 22, 12)):
            p.drawLine(x1, y1, x2, y2)
    p.end()
    return QIcon(pixmap)


def application_icon():
    pixmap = QPixmap(128, 128)
    pixmap.fill(Qt.GlobalColor.transparent)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#11283e"))
    p.drawRoundedRect(QRectF(1, 1, 126, 126), 28, 28)
    route_pen = QPen(QColor("#13b89c"), 9)
    route_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    route_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(route_pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawPolyline(QPolygonF([QPointF(30, 85), QPointF(55, 85), QPointF(55, 42), QPointF(98, 42)]))
    p.drawPolyline(QPolygonF([QPointF(82, 26), QPointF(98, 42), QPointF(82, 58)]))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#ffffff"))
    p.drawEllipse(QPointF(30, 85), 8, 8)
    p.drawEllipse(QPointF(55, 42), 5, 5)
    p.end()
    return QIcon(pixmap)


class Card(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("card")


class Metric(Card):
    def __init__(self, title, value, subtitle):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(17, 9, 17, 9)
        layout.setSpacing(3)
        self.setMaximumHeight(83)
        label = QLabel(title)
        label.setObjectName("muted")
        self.value = QLabel(value)
        self.value.setObjectName("metric")
        self.note = QLabel(subtitle)
        self.note.setObjectName("small")
        layout.addWidget(label)
        layout.addWidget(self.value)
        layout.addWidget(self.note)


class CoreGrid(QWidget):
    def __init__(self):
        super().__init__()
        self.mask = 0
        self.observed = False
        self.setFixedHeight(176)

    def set_mask(self, mask):
        self.mask = mask
        self.observed = True
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        dx, dy = self.width() / 4, self.height() / 4
        for bit in range(16):
            x, y = (bit % 4 + .5) * dx, (bit // 4 + .5) * dy
            active = bool(self.mask & 1 << bit)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#d4f4e9" if active else "#edf1f6"))
            painter.drawRoundedRect(QRectF(x - 27, y - 19, 54, 38), 9, 9)
            painter.setBrush(QColor("#11a88d" if active else "#b9c6d5"))
            painter.drawEllipse(QPointF(x - 13, y - 6), 3, 3)
            painter.setPen(QColor("#087b68" if active else "#62758b"))
            painter.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
            painter.drawText(QRectF(x - 9, y - 14, 32, 18),
                             Qt.AlignmentFlag.AlignCenter, f"{bit + 1:02d}")
            painter.setFont(QFont("Microsoft YaHei UI", 7))
            painter.drawText(QRectF(x - 25, y + 3, 50, 16), Qt.AlignmentFlag.AlignCenter,
                             "运行" if active else ("空闲" if self.observed else "待采样"))


class Plot(QWidget):
    def __init__(self, title="", color="#0b9c8f"):
        super().__init__()
        self.title = title
        self.color = color
        self.values = None
        self.scatter = False
        self.setMinimumSize(270, 210)
        self.setObjectName("plot")

    def set_data(self, x, y, scatter=False):
        x, y = np.asarray(x).reshape(-1), np.asarray(y).reshape(-1)
        n = min(len(x), len(y))
        step = max(1, n // (14000 if scatter else 3500))
        x, y = x[:n:step], y[:n:step]
        finite = np.isfinite(x) & np.isfinite(y)
        self.values = (x[finite], y[finite])
        self.scatter = scatter
        self.update()

    def clear(self):
        self.values = None
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#ffffff"))
        p.setFont(QFont("Microsoft YaHei UI", 10, QFont.Weight.DemiBold))
        p.setPen(QColor("#273c52"))
        p.drawText(17, 25, self.title)
        box = QRectF(57, 43, max(10, self.width() - 77), max(10, self.height() - 82))
        p.setPen(QPen(QColor("#eaf0f6"), 1))
        for i in range(6):
            x, y = box.left() + box.width() * i / 5, box.top() + box.height() * i / 5
            p.drawLine(QPointF(x, box.top()), QPointF(x, box.bottom()))
            p.drawLine(QPointF(box.left(), y), QPointF(box.right(), y))
        if self.values is None or len(self.values[0]) == 0:
            p.setPen(QColor("#9aaaba"))
            p.setFont(QFont("Microsoft YaHei UI", 9))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, "等待真实回传数据 / 载入本地文件")
            return
        x, y = self.values
        xmin, xmax, ymin, ymax = float(x.min()), float(x.max()), float(y.min()), float(y.max())
        if self.scatter:
            extent = max(abs(xmin), abs(xmax), abs(ymin), abs(ymax), 1) * 1.12
            aspect = box.width() / box.height()
            xmin, xmax = -extent * max(1, aspect), extent * max(1, aspect)
            ymin, ymax = -extent * max(1, 1 / aspect), extent * max(1, 1 / aspect)
        else:
            if xmax == xmin:
                xmax += 1
            padding = max((ymax - ymin) * .1, .1)
            ymin, ymax = ymin - padding, ymax + padding
        px = box.left() + (x - xmin) / (xmax - xmin) * box.width()
        py = box.bottom() - (y - ymin) / (ymax - ymin) * box.height()
        polygon = QPolygonF([QPointF(float(a), float(b)) for a, b in zip(px, py)])
        p.save()
        p.setClipRect(box)
        p.setPen(QPen(QColor(self.color), 1.8 if self.scatter else 1.3))
        if self.scatter:
            p.drawPoints(polygon)
        else:
            p.drawPolyline(polygon)
        p.restore()
        p.setPen(QColor("#8191a3"))
        p.setFont(QFont("Segoe UI", 8))
        for i in range(3):
            value = ymin + (ymax - ymin) * i / 2
            yp = box.bottom() - box.height() * i / 2
            p.drawText(QRectF(0, yp - 9, 50, 20), Qt.AlignmentFlag.AlignRight, f"{value:.3g}")
            value = xmin + (xmax - xmin) * i / 2
            xp = box.left() + box.width() * i / 2
            p.drawText(QRectF(xp - 36, box.bottom() + 7, 72, 20),
                       Qt.AlignmentFlag.AlignCenter, f"{value:.3g}")


class ImageView(QLabel):
    def __init__(self, text="等待图像数据"):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(220, 260)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        self.setStyleSheet("background:#102335;color:#91a8bb;border-radius:12px;")
        self.image = None

    def set_array(self, array, gray=False):
        values = (np.clip(array, 0, 1) * 255).astype(np.uint8)
        if gray:
            image = QImage(values.data, values.shape[1], values.shape[0], values.strides[0],
                           QImage.Format.Format_Grayscale8).copy()
        else:
            t = values.astype(np.float32) / 255
            rgb = np.stack([np.clip(t * 1.6 - .5, 0, 1),
                            np.clip(t * 1.25, 0, 1),
                            np.clip(.12 + t * .9, 0, 1)], axis=-1)
            rgb = (rgb * 255).astype(np.uint8)
            image = QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0],
                           QImage.Format.Format_RGB888).copy()
        self.set_image(image)

    def set_image(self, image):
        self.image = image.copy()
        self._fit()

    def clear_image(self, message="等待图像数据"):
        self.image = None
        self.setPixmap(QPixmap())
        self.setText(message)

    def _fit(self):
        if self.image is not None:
            self.setPixmap(QPixmap.fromImage(self.image).scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, event):
        self._fit()
        super().resizeEvent(event)
