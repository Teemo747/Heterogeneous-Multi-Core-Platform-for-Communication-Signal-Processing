"""Explicit, selectable interpretations of raw result bytes."""

from pathlib import Path
import math
import numpy as np

FORMATS = {
    "IQ · int16 小端": ("<i2", True),
    "IQ · int16 大端": (">i2", True),
    "幅值 · uint16 小端": ("<u2", False),
    "幅值 · int16 小端": ("<i2", False),
    "幅值 · float32 小端": ("<f4", False),
    "幅值 · float64 小端": ("<f8", False),
    "幅值 · uint8": ("u1", False),
}


def samples(path: str, format_name: str) -> np.ndarray:
    dtype, iq = FORMATS[format_name]
    sample_bytes = np.dtype(dtype).itemsize * (2 if iq else 1)
    if Path(path).stat().st_size % sample_bytes:
        raise ValueError(f"文件长度不是每样点 {sample_bytes} 字节的整数倍，可能为不完整数据或格式选择不正确")
    raw = np.fromfile(path, dtype=np.dtype(dtype))
    if iq:
        raw = raw[:len(raw) // 2 * 2].reshape(-1, 2).astype(np.float64)
        return raw[:, 0] + 1j * raw[:, 1]
    return raw.astype(np.float64)


def image_data(values: np.ndarray, width: int, height: int, dynamic_db=55) -> np.ndarray:
    if len(values) != width * height:
        raise ValueError(f"预览需要 {width * height:,} 个样点，当前只有 {len(values):,} 个；请调整格式或宽高")
    magnitude = np.nan_to_num(np.abs(values[:width * height]), nan=0.0, posinf=0.0)
    peak = float(magnitude.max())
    if peak <= 0:
        normalized = np.zeros_like(magnitude)
    else:
        db = 20 * np.log10(np.maximum(magnitude / peak, 1e-8))
        normalized = np.clip((db + dynamic_db) / dynamic_db, 0, 1)
    return normalized.reshape(height, width)


def bits_from_file(path: str, mode="自动识别") -> np.ndarray:
    raw = Path(path).read_bytes()
    if mode == "自动识别":
        try:
            text = raw.decode("ascii").strip()
            tokens = text.replace(",", " ").split()
            if tokens and all(t in ("0", "1") for t in tokens):
                return np.array([int(t) for t in tokens], dtype=np.uint8)
        except UnicodeDecodeError:
            pass
        if len(raw) % 2 == 0:
            values = np.frombuffer(raw, dtype="<u2")
            if len(values) and np.isin(values, [0, 1]).all():
                return values.astype(np.uint8)
        values = np.frombuffer(raw, dtype=np.uint8)
        if len(values) and np.isin(values, [0, 1]).all():
            return values
        return np.unpackbits(values, bitorder="big")
    if mode == "int16 数值 0/1":
        if len(raw) % 2:
            raise ValueError("int16 比特文件的字节数必须为偶数")
        values = np.frombuffer(raw, dtype="<u2")
        if not np.isin(values, [0, 1]).all():
            raise ValueError("文件中存在 0/1 以外的 int16 数值")
        return values.astype(np.uint8)
    if mode == "uint8 数值 0/1":
        values = np.frombuffer(raw, dtype=np.uint8)
        if not np.isin(values, [0, 1]).all():
            raise ValueError("文件中存在 0/1 以外的字节")
        return values
    return np.unpackbits(np.frombuffer(raw, dtype=np.uint8), bitorder="big")


def text_or_binary_wave(path: str) -> np.ndarray:
    """Legacy local trace files are often ASCII despite their .dat extension."""
    with open(path, "rb") as stream:
        prefix = stream.read(4096)
    if prefix and all(c in b"0123456789+-.eE,; \t\r\n" for c in prefix):
        values = np.loadtxt(path, delimiter="," if b"," in prefix else None)
        return np.asarray(values).reshape(-1)
    return np.fromfile(path, dtype="<i2").astype(np.float64)
