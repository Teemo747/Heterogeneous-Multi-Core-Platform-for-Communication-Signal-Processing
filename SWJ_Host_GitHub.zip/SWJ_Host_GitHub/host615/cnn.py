"""AMC local data records and host FFT analysis."""
import base64
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import zipfile
import struct

import numpy as np

CLASSES = ("bpsk", "qpsk", "8psk", "16qam")
CLASS_NAMES = dict(zip(CLASSES, ("BPSK", "QPSK", "8PSK", "16QAM")))
FFT_SIZE, HOP = 1024, 256
MAX_SAMPLES = 65536


@dataclass
class CNNResult:
    iq: np.ndarray
    sample_rate_hz: float
    scores: dict | None = None
    source: str = "reference"
    sample_name: str = ""
    reference_label: str | None = None
    snr_db: float | None = None
    inference_ms: float | None = None
    pipeline_ms: float | None = None
    device: str = ""
    samples_per_symbol: int | None = None
    symbol_offset: int = 0

    @property
    def winner(self):
        return max(CLASSES, key=self.scores.__getitem__) if self.scores else None


def finite_number(value, name, low=None, high=None, optional=False):
    if value is None and optional:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + "必须为有限数值")
    try:
        number = float(value)
    except OverflowError as exc:
        raise ValueError(name + "数值过大") from exc
    if not math.isfinite(number) or (low is not None and number < low) or (high is not None and number > high):
        raise ValueError(name + "数值超出有效范围")
    return number


def validate_iq(iq):
    array = np.asarray(iq)
    if array.ndim != 1 or not FFT_SIZE <= array.size <= MAX_SAMPLES or not np.issubdtype(array.dtype, np.number):
        raise ValueError(f"I/Q 需为一维复数序列，长度 {FFT_SIZE}–{MAX_SAMPLES}")
    if not np.isfinite(array).all() or np.max(np.abs(array), initial=0) > 1e12:
        raise ValueError("I/Q 含无效或过大的数值")
    return np.asarray(array, dtype=np.complex64)


def symbol_alignment(samples_per_symbol, offset=0):
    if samples_per_symbol is None:
        if offset != 0:
            raise ValueError("未提供符号间隔时偏移应为 0")
        return None, 0
    if isinstance(samples_per_symbol, bool) or not isinstance(samples_per_symbol, int) or not 1 <= samples_per_symbol <= 256:
        raise ValueError("每符号采样数需为 1–256 的整数")
    if isinstance(offset, bool) or not isinstance(offset, int) or not 0 <= offset < samples_per_symbol:
        raise ValueError("符号偏移超出范围")
    return samples_per_symbol, offset


def compute_features(iq, sample_rate_hz):
    iq = validate_iq(iq)
    fs = finite_number(sample_rate_hz, "采样率", 1, 1e12)
    starts = np.arange(0, len(iq)-FFT_SIZE+1, HOP)
    frames = iq[starts[:, None]+np.arange(FFT_SIZE)[None, :]]
    window = np.hanning(FFT_SIZE)
    transformed = np.fft.fftshift(np.fft.fft(frames*window, axis=1), axes=1)
    power = np.abs(transformed)**2 / np.sum(window**2)
    ref = max(float(np.max(power)), 1e-24)
    tf_db = 10*np.log10(np.maximum(power/ref, 1e-9))
    spectrum_db = 10*np.log10(np.maximum(np.mean(power, axis=0)/ref, 1e-9))
    rms = np.maximum(np.sqrt(np.mean(np.abs(frames)**2, axis=1, keepdims=True)), 1e-12)
    normalized_time = frames/rms
    normalized_fft = transformed/np.sqrt(np.sum(window**2))/rms
    cnn_input = np.stack((normalized_time.real, normalized_time.imag,
                          normalized_fft.real, normalized_fft.imag), axis=1).astype(np.float32)
    return {"fft_complex": transformed, "cnn_input": cnn_input, "frequency_khz": np.fft.fftshift(np.fft.fftfreq(FFT_SIZE, 1/fs))/1000,
            "time_ms": (starts+FFT_SIZE/2)/fs*1000,
            "spectrum_db": spectrum_db, "tf_db": tf_db,
            "duration_ms": len(iq)/fs*1000, "sample_rate_hz": fs}


def to_document(result):
    iq = validate_iq(result.iq)
    data = np.column_stack((iq.real, iq.imag)).astype("<f4").tobytes()
    return {"schema": "615.amc.result.v1", "scene": "automatic_modulation_classification",
            "source": result.source, "classes": list(CLASSES), "scores": result.scores,
            "sample_name": result.sample_name, "sample_rate_hz": result.sample_rate_hz,
            "iq_format": "float32_le_interleaved_iq", "iq_base64": base64.b64encode(data).decode("ascii"),
            "iq_sha256": hashlib.sha256(data).hexdigest(), "fft_size": FFT_SIZE, "hop": HOP,
            "reference_label": result.reference_label, "snr_db": result.snr_db,
            "samples_per_symbol": result.samples_per_symbol, "symbol_offset": result.symbol_offset,
            "timing": {"inference_ms": result.inference_ms, "pipeline_ms": result.pipeline_ms},
            "device": result.device,
            "note": "Reference records retain file-supplied values; host FFT is local computation; device origin is unverified."}


def from_document(doc):
    if not isinstance(doc, dict) or doc.get("schema") != "615.amc.result.v1" or doc.get("scene") != "automatic_modulation_classification":
        raise ValueError("请选择有效的 AMC 自动调制识别结果文件")
    if doc.get("source") not in ("reference", "external") or doc.get("classes") != list(CLASSES):
        raise ValueError("结果来源或类别顺序无效")
    if doc.get("fft_size") != FFT_SIZE or doc.get("hop") != HOP or doc.get("iq_format") != "float32_le_interleaved_iq":
        raise ValueError("FFT 参数或 I/Q 格式不匹配")
    scores = doc.get("scores")
    if not isinstance(scores, dict) or set(scores) != set(CLASSES):
        raise ValueError("结果需包含四类得分")
    scores = {k: finite_number(scores[k], "分类得分", 0, 1) for k in CLASSES}
    if abs(sum(scores.values())-1) > .001:
        raise ValueError("四类得分之和需为 1")
    encoded = doc.get("iq_base64")
    if not isinstance(encoded, str) or len(encoded) > MAX_SAMPLES*12:
        raise ValueError("I/Q 数据缺失或过大")
    try:
        data = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError("I/Q Base64 编码无效") from exc
    if len(data) % 8 or not FFT_SIZE*8 <= len(data) <= MAX_SAMPLES*8:
        raise ValueError("I/Q 数据长度无效")
    if hashlib.sha256(data).hexdigest() != doc.get("iq_sha256"):
        raise ValueError("I/Q 数据校验不匹配")
    values = np.frombuffer(data, "<f4").reshape(-1, 2)
    iq = validate_iq(values[:, 0]+1j*values[:, 1])
    fs = finite_number(doc.get("sample_rate_hz"), "采样率", 1, 1e12)
    timing = doc.get("timing", {})
    if not isinstance(timing, dict):
        raise ValueError("计时数据格式无效")
    strings = [doc.get(k, "") for k in ("sample_name", "device")]
    if any(not isinstance(v, str) or len(v) > 180 for v in strings):
        raise ValueError("样本名称或设备说明无效")
    reference = doc.get("reference_label")
    if reference is not None and reference not in CLASSES:
        raise ValueError("参考类别无效")
    sps, offset = symbol_alignment(doc.get("samples_per_symbol"), doc.get("symbol_offset", 0))
    return CNNResult(iq, fs, scores=scores, source=doc["source"], sample_name=strings[0], reference_label=reference,
                     snr_db=finite_number(doc.get("snr_db"), "SNR", -100, 100, True),
                     inference_ms=finite_number(timing.get("inference_ms"), "推理耗时", 0, None, True),
                     pipeline_ms=finite_number(timing.get("pipeline_ms"), "流程耗时", 0, None, True),
                     device=strings[1], samples_per_symbol=sps, symbol_offset=offset)


def load_result(path):
    path = Path(path)
    if path.stat().st_size > 2*1024*1024:
        raise ValueError("结果文件过大")
    data = path.read_bytes()
    if data.startswith(b"615AMC1\0"):
        if len(data) < 12:
            raise ValueError("AMC 文件头不完整")
        length = struct.unpack("<I", data[8:12])[0]
        if not 1 <= length <= 16384 or 12+length > len(data):
            raise ValueError("AMC 文件头长度无效")
        doc = json.loads(data[12:12+length].decode("utf8"))
        if not isinstance(doc, dict) or doc.get("iq_bytes") != len(data)-12-length:
            raise ValueError("AMC 载荷长度不匹配")
        doc["iq_base64"] = base64.b64encode(data[12+length:]).decode("ascii")
    elif path.suffix.lower() == ".json":
        doc = json.loads(data.decode("utf8"))
    else:
        raise ValueError("请选择 AMC 结果 .bin；裸 I/Q 请使用载入 I/Q")
    return from_document(doc)

def save_result(path, result):
    path = Path(path)
    doc = to_document(result); from_document(doc)
    if path.suffix.lower() == ".bin":
        payload = base64.b64decode(doc.pop("iq_base64"))
        doc["iq_bytes"] = len(payload)
        metadata = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode("utf8")
        if len(metadata) > 16384:
            raise ValueError("AMC 元数据过大")
        path.write_bytes(b"615AMC1\0"+struct.pack("<I", len(metadata))+metadata+payload)
    else:
        path.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf8")

def load_iq(path, fmt="int16", sample_rate_hz=1e6):
    sps, offset = None, 0
    if path.suffix.lower() == ".npz":
        try:
            with zipfile.ZipFile(path) as z:
                if sum(info.file_size for info in z.infolist()) > 4*1024*1024:
                    raise ValueError("NPZ 解压数据过大")
        except zipfile.BadZipFile as exc:
            raise ValueError("NPZ 文件损坏或格式无效") from exc
        with np.load(path, allow_pickle=False) as data:
            if not {"i", "q", "sample_rate_hz"} <= set(data.files):
                raise ValueError("NPZ 需包含 i、q、sample_rate_hz")
            i, q = data["i"], data["q"]
            if i.ndim != 1 or q.shape != i.shape or i.size > MAX_SAMPLES:
                raise ValueError("NPZ 的 I/Q 数组形状无效")
            if np.iscomplexobj(i) or np.iscomplexobj(q):
                raise ValueError("i 和 q 必须分别为实数数组")
            iq = validate_iq(i+1j*q)
            fs = finite_number(float(data["sample_rate_hz"].item()), "采样率", 1, 1e12)
            if "samples_per_symbol" in data.files:
                raw_sps = data["samples_per_symbol"].item()
                raw_offset = data["symbol_offset"].item() if "symbol_offset" in data.files else 0
                sps, offset = symbol_alignment(raw_sps, raw_offset)
    else:
        if path.stat().st_size > MAX_SAMPLES*8:
            raise ValueError("裸 I/Q 文件过大；请先提取所需信号段")
        raw = path.read_bytes()
        if raw.startswith(bytes.fromhex("ddccbbaa")):
            raise ValueError("检测到平台 Config 头；请先提取 I/Q 载荷，不能将整个 3M 文件当裸样点")
        if fmt not in ("int16", "float32"):
            raise ValueError("请选择有效的 I/Q 格式")
        dtype = "<i2" if fmt == "int16" else "<f4"
        width = np.dtype(dtype).itemsize
        if len(raw) % (width*2):
            raise ValueError("文件长度不是 I/Q 采样对字节数的整数倍")
        values = np.frombuffer(raw, dtype=dtype).reshape(-1, 2).astype(np.float32)
        if fmt == "int16":
            values /= 32768
        iq = validate_iq(values[:, 0]+1j*values[:, 1])
        fs = finite_number(sample_rate_hz, "采样率", 1, 1e12)
    return CNNResult(iq, fs, source="local", sample_name=path.name, samples_per_symbol=sps, symbol_offset=offset)


def export_iq(path, sample):
    iq = validate_iq(sample.iq)
    path = path.with_suffix(".npz")
    metadata = {"samples_per_symbol": sample.samples_per_symbol, "symbol_offset": sample.symbol_offset} if sample.samples_per_symbol is not None else {}
    np.savez_compressed(path, i=iq.real, q=iq.imag, sample_rate_hz=sample.sample_rate_hz, **metadata)
    peak = max(float(np.abs(iq.real).max()), float(np.abs(iq.imag).max()), 1e-12)
    scale = .95*32767/peak
    raw = np.round(np.column_stack((iq.real, iq.imag))*scale).astype("<i2").tobytes()
    bin_path = path.with_suffix(".iq.bin"); bin_path.write_bytes(raw)
    meta = {"format": "int16_le_interleaved_iq", "samples": len(iq), "sample_rate_hz": sample.sample_rate_hz,
            "samples_per_symbol": sample.samples_per_symbol, "symbol_offset": sample.symbol_offset,
            "quantization_scale": scale, "sha256": hashlib.sha256(raw).hexdigest(),
            "note": "Raw IQ only. NOT a valid platform DM file; Config/address/alignment packing is still required."}
    path.with_suffix(".iq.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf8")
    return path
