"""Public application identity."""
TEAM_NAME = "路由不迷路"
APP_TITLE = "路由不迷路信号处理平台"
