"""Socket I/O and paced uploads live off the GUI thread."""

from dataclasses import asdict, dataclass
from datetime import datetime
import errno
import hashlib
import ipaddress
import json
from pathlib import Path
import select
import socket
import threading
import time
import uuid

from PyQt6.QtCore import QObject, pyqtSignal

from .protocol import ALGORITHMS, MEMORIES, end, file_packets, hello, parse_control


@dataclass
class Settings:
    local_ip: str = "192.168.1.11"
    local_port: int = 8080
    remote_ip: str = "192.168.1.10"
    remote_port: int = 5001
    algorithm: str = "mimo"
    rate_kib: int = 1024
    chunk_size: int = 1024
    file_gap_ms: int = 800
    handshake_ms: int = 1000
    output_dir: str = "results"
    expected_bytes: int = 65024

    def validate(self):
        local = ipaddress.IPv4Address(self.local_ip)
        remote = ipaddress.IPv4Address(self.remote_ip)
        if local.is_multicast or remote.is_multicast or remote.is_unspecified:
            raise ValueError("请填写有效的单播 IPv4 地址")
        if not 0 <= self.local_port <= 65535 or not 1 <= self.remote_port <= 65535:
            raise ValueError("本机端口需在 0–65535 范围（0 自动分配），FPGA 端口需在 1–65535 范围")
        if self.algorithm not in ALGORITHMS:
            raise ValueError("请选择支持的算法")
        if not 16 <= self.chunk_size <= 1400:
            raise ValueError("UDP 数据块长度需在 16–1400 字节")
        if self.rate_kib < 16 or self.handshake_ms < 100 or self.expected_bytes < 1:
            raise ValueError("传输速率、握手超时或预期结果长度无效")
        if self.file_gap_ms < 100:
            raise ValueError("文件间隔至少 100 ms，给板端 DMA 留出处理时间")


class FrameWriter:
    def __init__(self, settings: Settings, index: int):
        folder = Path(settings.output_dir) / datetime.now().strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%H%M%S_%f")
        self.path = folder / f"{settings.algorithm}_{stamp}_{index:04d}.partial.bin"
        self.stream = self.path.open("xb")
        self.algorithm = settings.algorithm
        self.expected = settings.expected_bytes
        self.size = 0
        self.packets = 0
        self.started = time.monotonic()
        self.hasher = hashlib.sha256()

    def write(self, data: bytes):
        self.stream.write(data)
        self.hasher.update(data)
        self.size += len(data)
        self.packets += 1

    def finish(self, reason: str = "finished") -> dict:
        self.stream.close()
        complete = reason == "finished" and self.size == self.expected
        if complete:
            target = self.path.with_name(self.path.name.replace(".partial.bin", ".bin"))
            self.path.rename(target)
            self.path = target
        result = {
            "path": str(self.path.resolve()),
            "algorithm": self.algorithm,
            "bytes": self.size,
            "expected_bytes": self.expected,
            "packets": self.packets,
            "seconds": round(time.monotonic() - self.started, 6),
            "complete": complete,
            "reason": reason,
            "sha256": self.hasher.hexdigest(),
            "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
            "integrity_note": "SHA256 is local-file identity; the wire protocol has no sequence/checksum ACK.",
        }
        self.path.with_suffix(".json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return result


class Session(QObject):
    event = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.settings = Settings()
        self.sock: socket.socket | None = None
        self.verified = False
        self.needs_board_reset = False
        self.receive_enabled = True
        self._shutdown = threading.Event()
        self._cancel = threading.Event()
        self._hello_event = threading.Event()
        self._pending_hello = b""
        self._io_lock = threading.Lock()
        self._receiver: threading.Thread | None = None
        self._task: threading.Thread | None = None
        self._frame: FrameWriter | None = None
        self._frame_index = 0
        self._last_progress = 0.0
        self._session_tag = uuid.uuid4().hex[:8]
        self.total_rx = 0
        self.total_tx = 0

    @property
    def busy(self):
        return bool(self._task and self._task.is_alive())

    def emit(self, kind: str, **values):
        try:
            self.event.emit({"kind": kind, **values})
        except RuntimeError:
            pass

    def log(self, text: str, level: str = "info"):
        self.emit("log", text=text, level=level)

    def open(self, settings: Settings):
        if self.sock:
            raise RuntimeError("请先断开当前连接")
        settings.validate()
        folder = Path(settings.output_dir)
        folder.mkdir(parents=True, exist_ok=True)
        test = folder / f".write-test-{self._session_tag}"
        test.write_bytes(b"")
        test.unlink()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
            sock.bind((settings.local_ip, settings.local_port))
            sock.setblocking(False)
        except Exception as exc:
            sock.close()
            if isinstance(exc, OSError):
                code = getattr(exc, "winerror", None) or exc.errno
                if code in (errno.EADDRNOTAVAIL, 10049):
                    raise ValueError(
                        f"本机 IPv4 {settings.local_ip} 当前不能绑定。请选择“刷新本机地址”列出的实际网卡地址；"
                        "如需使用 工程默认地址 192.168.1.11，请先在 Windows 网卡中配置该地址。"
                    ) from exc
                if code in (errno.EADDRINUSE, 10048):
                    raise ValueError(
                        f"本机 UDP 端口 {settings.local_port} 已被占用。请关闭占用它的旧上位机，"
                        "或修改本机端口（填 0 可自动分配）；Zynq 目标端口仍按固件配置。"
                    ) from exc
            raise
        self.settings = Settings(**asdict(settings))
        self.settings.local_port = sock.getsockname()[1]
        self.sock = sock
        self.verified = False
        self._shutdown.clear()
        self._cancel.clear()
        self.total_rx = self.total_tx = 0
        self._frame_index = 0
        self._receiver = threading.Thread(target=self._receive_loop, daemon=True, name="signal-platform-udp-rx")
        self._receiver.start()
        self.emit("link", state="bound")
        self.log(f"本机已绑定 {settings.local_ip}:{settings.local_port}，探测板端握手…")
        self.probe()

    def _start_task(self, target):
        if self.busy:
            raise RuntimeError("当前操作尚未结束")
        self._cancel.clear()

        def run():
            try:
                target()
            except InterruptedError:
                self.log("操作已停止", "warning")
            except Exception as exc:
                self.log(str(exc), "error")
                self.emit("operation_error", text=str(exc))
            finally:
                self.emit("task_done")

        self._task = threading.Thread(target=run, daemon=True, name="signal-platform-udp-tx")
        self._task.start()

    def _send(self, data: bytes):
        if self._shutdown.is_set() or not self.sock:
            raise ConnectionError("UDP 端口已经关闭")
        with self._io_lock:
            size = self.sock.sendto(data, (self.settings.remote_ip, self.settings.remote_port))
        if size != len(data):
            raise OSError("UDP 发送长度不一致")
        self.total_tx += size

    def _check_cancel(self):
        if self._cancel.is_set() or self._shutdown.is_set():
            raise InterruptedError()

    def _handshake(self, memory: str):
        token = hello(memory)
        # A previous echo is not evidence that this probe succeeded.
        self.verified = False
        self.emit("link", state="probing")
        self._hello_event.clear()
        self._pending_hello = token
        try:
            for attempt in range(3):
                self._check_cancel()
                self._send(token)
                deadline = time.monotonic() + self.settings.handshake_ms / 1000
                while time.monotonic() < deadline:
                    self._check_cancel()
                    if self._hello_event.wait(0.02):
                        self.verified = True
                        self.emit("link", state="verified")
                        self.emit("handshake", memory=memory)
                        self.log(f"{memory} 握手成功：UDP 通信程序已应答")
                        return
                self.log(f"{memory} 握手未获应答，第 {attempt + 1}/3 次", "warning")
            raise TimeoutError("板端握手超时。请检查本机 IPv4、网线、防火墙及 Zynq 程序。")
        finally:
            self._pending_hello = b""
            if not self.verified and not self._shutdown.is_set():
                self.emit("link", state="unverified")

    def probe(self, memory: str = "PM"):
        self._start_task(lambda: self._handshake(memory))

    def set_algorithm(self, key: str, expected_bytes: int | None = None, send_command=True):
        if self.busy:
            raise RuntimeError("传输过程中不能切换算法")
        if self._frame is not None:
            raise RuntimeError("当前结果帧尚未结束，请先停止板端输出并等待 finished")
        self.settings.algorithm = key
        self.settings.expected_bytes = expected_bytes or ALGORITHMS[key].result_bytes
        command_sent = bool(self.sock and send_command)
        if command_sent:
            self._send(ALGORITHMS[key].command)
            self.log(f"已发送算法选择 {ALGORITHMS[key].command.decode()}；固件不返回算法确认包")
        self.emit("algorithm", key=key, command_sent=command_sent)

    def upload(self, queue: list[tuple[str, list[Path]]]):
        if not self.sock or not self.verified:
            raise RuntimeError("请先完成板端握手")
        if self.needs_board_reset:
            raise RuntimeError("上次文件中途停止。请先重启板端通信程序，再解除中止保护。")
        if self._frame:
            raise RuntimeError("正在接收结果，请先停止板端运行并等待当前帧结束")
        clean = []
        for memory, paths in queue:
            if memory not in MEMORIES:
                raise ValueError("存储区错误")
            paths = [Path(p).resolve() for p in paths]
            for path in paths:
                if not path.is_file() or path.stat().st_size == 0:
                    raise ValueError(f"文件不存在或为空：{path}")
                with path.open("rb") as stream:
                    stream.read(1)
            if paths:
                clean.append((memory, paths, sum(p.stat().st_size for p in paths)))
        if not clean:
            raise ValueError("请先选择 PM、CM 或 DM 文件")
        self._start_task(lambda: self._upload_loop(clean))

    def _upload_loop(self, queue):
        overall_total = sum(size for _, _, size in queue)
        overall_sent = 0
        uncommitted = False
        began = time.monotonic()
        try:
            self._send(ALGORITHMS[self.settings.algorithm].command)
            self.emit("algorithm", key=self.settings.algorithm, command_sent=True)
            for memory, paths, total in queue:
                self.emit("phase", text=f"{memory} 握手")
                self._handshake(memory)
                self.emit("phase", text=f"正在下发 {memory}")
                sent = 0
                last = 0.0
                deadline = time.monotonic()
                for data in file_packets(paths, self.settings.chunk_size):
                    self._check_cancel()
                    self._send(data)
                    uncommitted = True
                    sent += len(data)
                    overall_sent += len(data)
                    now = time.monotonic()
                    if now - last >= 0.04 or sent == total:
                        self.emit("tx_progress", memory=memory, sent=sent, total=total,
                                  overall=overall_sent, overall_total=overall_total,
                                  seconds=now - began, wire_bytes=self.total_tx)
                        last = now
                    deadline = max(deadline + len(data) / (self.settings.rate_kib * 1024),
                                   time.monotonic())
                    if self._cancel.wait(max(0.0, deadline - time.monotonic())):
                        raise InterruptedError()
                if sent != total:
                    raise OSError(f"{memory} 文件在发送过程中发生变化，请重新选择文件")
                self._check_cancel()
                self._send(end(memory))
                uncommitted = False
                self.emit("memory_sent", memory=memory, bytes=sent)
                self.log(f"{memory} 已发送 {sent:,} 字节及 {end(memory).decode()}；等待板端处理")
                self.emit("phase", text=f"{memory} 已发送 · 等待板端 DMA")
                if self._cancel.wait(self.settings.file_gap_ms / 1000):
                    raise InterruptedError()
            self.emit("upload_done", seconds=time.monotonic() - began, bytes=overall_sent)
            self.emit("phase", text="下发结束 · 等待板端状态与结果")
        finally:
            if uncommitted:
                self.needs_board_reset = True
                self.emit("reset_required")
                self.log("文件中途终止，固件 hello 不会清空 total_bytes。请重启板端通信程序后再下发。", "error")

    def cancel(self):
        self._cancel.set()

    def acknowledge_board_reset(self):
        if self.busy:
            raise RuntimeError("请等待当前操作退出")
        self.needs_board_reset = False
        self.verified = False
        self.log("已解除中止保护，请重新连接并握手")

    def _receive_loop(self):
        sock = self.sock
        frame = None
        try:
            while not self._shutdown.is_set():
                ready, _, _ = select.select([sock], [], [], 0.05)
                if not ready:
                    continue
                while not self._shutdown.is_set():
                    try:
                        data, peer = sock.recvfrom(65535)
                    except BlockingIOError:
                        break
                    except ConnectionResetError:
                        # Windows ICMP port-unreachable must not kill later probes.
                        break
                    if peer != (self.settings.remote_ip, self.settings.remote_port):
                        continue
                    parsed = parse_control(data)
                    if parsed:
                        kind, value = parsed
                        if kind in ("sar_stage", "sar_times"):
                            continue  # Discard retired telemetry without corrupting result payload.
                        if kind == "hello":
                            if data == self._pending_hello:
                                self._hello_event.set()
                        elif kind == "finished":
                            if frame:
                                self._finish_frame(frame)
                                frame = None
                                self._frame = None
                            else:
                                self.log("收到 finished，但本帧没有数据", "warning")
                        else:
                            self.emit("telemetry", name=kind, value=value)
                        continue
                    if not self.receive_enabled:
                        continue
                    if frame is None:
                        self._frame_index += 1
                        frame = FrameWriter(self.settings, self._frame_index)
                        self._frame = frame
                    frame.write(data)
                    self.total_rx += len(data)
                    now = time.monotonic()
                    if now - self._last_progress > 0.05:
                        self.emit("rx_progress", received=frame.size, expected=frame.expected,
                                  packets=frame.packets, total_rx=self.total_rx)
                        self._last_progress = now
        except (OSError, ValueError) as exc:
            if not self._shutdown.is_set():
                self.verified = False
                self.emit("link", state="unverified")
                self.log(f"接收失败：{exc}", "error")
                self.emit("operation_error", text=str(exc))
        finally:
            if frame:
                self._finish_frame(frame, "disconnected")
            self._frame = None

    def _finish_frame(self, frame, reason="finished"):
        try:
            self.emit("frame", **frame.finish(reason))
        except OSError as exc:
            self.log(f"结果文件未能完整保存：{exc}", "error")
            self.emit("operation_error", text=f"结果保存失败：{exc}")

    def close(self):
        self._cancel.set()
        self._shutdown.set()
        if self._task and self._task is not threading.current_thread():
            self._task.join(1.5)
        if self._receiver and self._receiver is not threading.current_thread():
            self._receiver.join(1.5)
        if self.sock:
            self.sock.close()
        self.sock = None
        self.verified = False
        self.emit("link", state="closed")
