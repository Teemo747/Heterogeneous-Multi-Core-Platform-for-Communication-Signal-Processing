# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

root = Path(SPECPATH)
a = Analysis(
    [str(root / "main.py")], pathex=[str(root)], binaries=[],
    datas=[(str(root / "README.md"), "."),
           (str(root / "docs" / "PROTOCOL.md"), "docs"),
           (str(root / "docs" / "AMC_INTERFACE.md"), "docs")],
    hiddenimports=[], hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[],
    noarchive=False,
)
# Qt 6.12 uses the Windows ICU API. Do not ship an incompatible same-name
# library found in Poppler/other tools on PATH. Preserve Qt-wheel-owned ICU.
a.binaries = [entry for entry in a.binaries if not (
    Path(entry[0]).name.lower().startswith("icu")
    and Path(entry[0]).suffix.lower() == ".dll"
    and "pyqt6" not in entry[1].lower()
)]
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="路由不迷路信号处理平台", debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=False, disable_windowed_traceback=True,
    icon=str(root / "assets" / "app.ico"),
)
