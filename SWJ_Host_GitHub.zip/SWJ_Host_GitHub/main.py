import argparse
import json
import os
from pathlib import Path
import sys
import traceback

from host615.branding import APP_TITLE, TEAM_NAME


def project_root():
    if getattr(sys, "frozen", False):
        folder = Path(sys.executable).resolve().parent
        return folder.parent.parent if folder.parent.name == "bin" else folder
    return Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("--screenshot", help="离屏保存主界面截图后退出")
    parser.add_argument("--algorithm", choices=("mimo", "cdma", "amc"), default=None,
                        help="选择启动时的算法")
    parser.add_argument("--data-dir", help="指定设置、日志和结果的存放目录")
    parser.add_argument("--load-result", help="启动后载入结果文件")
    args = parser.parse_args()
    if args.screenshot:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PyQt6.QtCore import QTimer
    from PyQt6.QtGui import QFont
    from PyQt6.QtWidgets import QApplication
    from host615.ui import MainWindow
    app = QApplication(sys.argv[:1])
    app.setApplicationName(APP_TITLE)
    app.setApplicationDisplayName(APP_TITLE)
    app.setOrganizationName(TEAM_NAME)
    app.setFont(QFont("Microsoft YaHei UI", 9))
    window = MainWindow(Path(args.data_dir).resolve() if args.data_dir else project_root())
    window.show()
    if args.algorithm:
        window.algorithm.setCurrentIndex(window.algorithm.findData(args.algorithm))
    if args.load_result:
        QTimer.singleShot(100, lambda: window.guarded(lambda: window.load_local_result(Path(args.load_result))))
    if args.screenshot:
        def capture():
            Path(args.screenshot).parent.mkdir(parents=True, exist_ok=True)
            window.grab().save(args.screenshot)
            Path(args.screenshot).with_suffix(".json").write_text(json.dumps({
                "platform": app.platformName(), "width": window.width(), "height": window.height(),
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            window.close()
        QTimer.singleShot(900, capture)
    return app.exec()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        log = project_root() / "startup_error.log"
        log.write_text(traceback.format_exc(), encoding="utf-8")
        raise
