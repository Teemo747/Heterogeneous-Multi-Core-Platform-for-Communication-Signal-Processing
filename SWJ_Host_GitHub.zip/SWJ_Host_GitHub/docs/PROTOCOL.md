# 当前上位机协议对照

当前板端选项为 MIMO/CDMA，AMC 支持本地结果和 I/Q 文件导入。SAR 上位机功能已移除，原固件未修改。AMC 的板端程序及传输适配尚未实现，上位机不向旧固件发送 AMC 指令或文件。

依据原工程 Display/Display 已展开文件，没有新增固件指令。原工程源码是协议依据；新 FACE 厂商 IO 测试工程只作硬件参考，不用于替换此协议、PS 配置、计数单位或计算逻辑。

## 地址

04swj0813/para_setting.ini：本机 192.168.1.11:8080，FPGA 192.168.1.10:5001。
udp_ddr3/src/udp_perf_server.h：UDP_CONN_PORT=5001。
udp_perf_server.c 约334行：回传目标取自收到报文的实际 IP、端口。因此应用使用同一绑定 socket 下发和接收。

## 主机→板端

| 报文 | 长度 | 含义 |
| --- | ---: | --- |
| algo_Air | 8 | MIMO / algoID=0 |
| algocdma | 8 | CDMA / algoID=1 |
| hello_pm / hello_cm / hello_dm | 8 | 原样回显的握手 |
| 文件原始数据 | 可变 | memcpy到DDR接收缓冲 |
| end_pm / end_cm / end_dm | 6 | 数据结束，调用dma_main |

全部为裸 ASCII，无 NUL、换行、JSON。
先握手并等回显，再发文件原始数据，最后 end。源码：udp_perf_server.c约338–435行。
end调用dma_main后清total_bytes，hello仅修改DDR_WR_ARDDR而不清total_bytes，所以中途取消不能靠hello复位。
数据包若长8且以hello/algo开头，或长6且以end开头，会误入控制分支。本项目拆成1字节及剩余字节两包，拼接字节不变。

## 板端→主机

| 报文 | 含义 |
| --- | --- |
| hello_pm / hello_cm / hello_dm | 握手回显 |
| core16statusFFFF | 十六进制16核掩码，最低位对应核1 |
| core16finish | 曾采到非零核状态后，核状态回到 0；不代表结果接收已结束 |
| algor_time0123 | 十六进制算法耗时计数 |
| sar_stage_time0010002000300040 | 旧固件保留消息，识别后丢弃，避免污染二进制结果 |
| msg_sar_stage02 | 旧固件保留消息，识别后丢弃，不显示 |
| 原始结果 | RD_DDR分包，一般每包1024字节 |
| finished | upload_end发送的一帧结束标记 |

源码：main.c约259–396行；udp_perf_server.c的sent_msg、handshake、RD_DDR、upload_end。
结果长度：dma_top_SAR.c的dma_back。控制消息仅在完整长度/内容匹配时识别，其余按二进制落盘。
没有分包/帧序号、文件ACK、远程reset/stop、运行模式切换、自动发现或结果类型元数据。

## 当前支持的板端结果长度

dma_top_SAR.c 中 dma_back() 当前实际执行的配置如下，注释掉的旧值不采用：

| 算法 | 命令 | 一帧结果字节数 |
| --- | --- | ---: |
| MIMO / 对空波形 | algo_Air | 65024 |
| CDMA | algocdma | 256 |

这些长度不能证明样点格式或端序，仍需与真实结果确认。

## 状态含义

- hello 回显只确认 Zynq 上的 UDP 通信程序应答，不检查 DMA、板间 IO、VU13P 的 bit、DDR4 或计算核。
- 每次重新握手先撤销旧确认；超时或接收失败后，下发按钮不再沿用旧的已确认状态。这里没有新增心跳或自动探测命令。
- 算法命令仅报告“本机已发送”；固件没有算法确认应答。
- core16finish 与 finished 独立处理。前者更新核状态，后者关闭本帧结果文件。
- 接收 finished 且长度匹配，仅表示本地帧边界与长度检查通过。原协议没有端到端序号或校验，无法据此证明内容无误。
- 新建或关闭会话清除实时遥测显示，避免把上次连接的核状态、计数显示为新设备状态；已保存的结果保留。

## 功能边界

旧文档的上位机停止/复位不是硬件复位。新应用优先保存持续回传的数据，停止板端请使用原VIO流程。
不擅自重写Config中的核掩码，不把本地Matlab参考数据冒充实时数据。
