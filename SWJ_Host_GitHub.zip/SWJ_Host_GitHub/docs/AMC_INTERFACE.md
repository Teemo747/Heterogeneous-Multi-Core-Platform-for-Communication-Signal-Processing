# AMC 自动调制识别文件接口

当前页面支持 BPSK、QPSK、8PSK、16QAM。启动时无信号、无类别结论。载入结果文件后展示该文件提供的采样及四类得分；载入原始 I/Q 时只计算并显示信号特征，不执行 CNN 推理。

## 数据来源与计算位置

`source=reference` 表示参考文件，界面明确标识其不是板端测量；`source=external` 表示外部结果文件，其设备声明未经上位机独立核实。分类得分不等于统计准确率。未测量的推理耗时为 null，不能用 PC 绘图或 FFT 时间代替板端时间。

当前 PC 实际执行：1024 点 Hann 窗 FFT、256 点步进、频谱及时频图。四通道候选 CNN 输入依次为归一化 I、Q、复 FFT 实部、复 FFT 虚部，形状为 `[窗口数, 4, 1024]`。8192 个复采样产生 29 个窗口。实际 CNN 训练、推理、VU13P PM/CM 与原工程 DM 封装尚未实现。

星座散点使用文件提供的 `samples_per_symbol` 和 `symbol_offset` 抽样；没有这些元数据时显示原始 I/Q 散点。该处理没有执行盲符号同步。

## AMC 二进制结果

自定义 `.bin` 是本地结果容器，不是平台 DM 或网络帧。

| 字段 | 长度 | 内容 |
| --- | ---: | --- |
| magic | 8 B | ASCII `615AMC1` 后接一个零字节 |
| metadata_length | 4 B | uint32 小端，JSON 元数据字节数 |
| metadata | 可变 | UTF-8 JSON，最多 16384 B |
| iq_payload | 可变 | float32 小端交错 I、Q，按元数据 `iq_bytes` 定长 |

元数据采用 `615.amc.result.v1`，`scene=automatic_modulation_classification`，包含 `classes=[bpsk,qpsk,8psk,16qam]`、四类归一化 `scores`、`source`、`sample_rate_hz`、`sample_name`、`reference_label`、可选 SNR、符号抽样参数、计时和设备声明。`iq_format=float32_le_interleaved_iq`，`fft_size=1024`，`hop=256`。四类得分均在 0–1 且总和在 1 的 0.001 误差内。

`iq_bytes` 指定剩余载荷长度，`iq_sha256` 校验载荷。文件总大小最多 2 MiB，接受 1024–65536 个有限复采样。导入前验证格式、参数、长度及校验，失败时保留已有有效视图。SHA256 用于发现数据损坏，不认证文件来源。

兼容 JSON 结果，其 I/Q 放在 `iq_base64`，其他校验和限制相同。导出图像时同时写出 PNG、独立 `.bin` 和 JSON。

## 原始输入

支持 NPZ 或 int16/float32 小端交错 I/Q。NPZ 需包含 `i`、`q`、`sample_rate_hz`，可提供 `samples_per_symbol`、`symbol_offset`；裸 `.bin` 的格式和采样率由界面指定。导入原始输入会清除旧类别及得分，防止旧结果与新采样混在一起。

`本地数据文件/02_输入IQ` 的裸 `.iq.bin` 为 int16 小端交错 I/Q；同名 `.iq.json` 提供来源和参数，NPZ 可保留符号参数。此处输入不自动包装为 PM/CM/DM。

## 与现有硬件平台的关系

MIMO/CDMA 的原始 UDP 收发流程保留。AMC 没有对应旧固件算法 ID，上位机不会为其发送算法切换或 3M 数据。后续必须实现板端程序和数据协议，才能把此页面用于真实 AMC 回传。FACE 厂商资料只作硬件参考。
