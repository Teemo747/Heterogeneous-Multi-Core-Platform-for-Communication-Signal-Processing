@echo off
setlocal
cd /d "%~dp0"
set "SOURCE_MODE="
if /I "%~1"=="--source" set "SOURCE_MODE=-Source"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" %SOURCE_MODE%
set "LAUNCH_EXIT=%ERRORLEVEL%"
if not "%LAUNCH_EXIT%"=="0" (
    echo.
    echo Startup failed. Read the message above and startup_error.log.
    pause
)
exit /b %LAUNCH_EXIT%
