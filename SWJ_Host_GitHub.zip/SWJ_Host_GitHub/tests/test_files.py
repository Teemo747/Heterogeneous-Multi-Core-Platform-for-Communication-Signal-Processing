import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from pathlib import Path
import json
import struct
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from PyQt6.QtWidgets import QApplication, QLabel, QPushButton, QComboBox
from host615.cnn import CLASSES, compute_features, load_iq, load_result, save_result

APP=QApplication.instance() or QApplication([])
FILES=Path(__file__).resolve().parent/"fixtures"/"01_结果数据"


class ResultFilesTests(unittest.TestCase):
    def test_all_four_amc_bins_are_self_contained_and_reference_marked(self):
        for key in CLASSES:
            with self.subTest(modulation=key):
                path=FILES/("AMC_"+key.upper()+".bin")
                record=load_result(path)
                self.assertEqual(record.source,"reference")
                self.assertEqual(record.winner,key)
                self.assertEqual(len(record.iq),8192)
                self.assertEqual(record.samples_per_symbol,8)
                self.assertEqual(compute_features(record.iq,record.sample_rate_hz)["cnn_input"].shape,(29,4,1024))
                with tempfile.TemporaryDirectory() as folder:
                    copy=Path(folder)/"record.bin";save_result(copy,record)
                    restored=load_result(copy)
                    np.testing.assert_array_equal(restored.iq,record.iq)
                    self.assertEqual(restored.scores,record.scores)

    def test_binary_header_length_and_payload_hash_are_validated(self):
        raw=(FILES/"AMC_16QAM.bin").read_bytes()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/"bad.bin"
            for malformed in (raw[:10],raw[:8]+struct.pack("<I",2**24)+raw[12:],raw[:-1],raw[:-1]+bytes([raw[-1]^1])):
                path.write_bytes(malformed)
                with self.assertRaises(ValueError):load_result(path)


class FileInterfaceTests(unittest.TestCase):
    def test_starts_empty_without_case_controls_or_ui_words(self):
        from host615.ui import MainWindow
        with tempfile.TemporaryDirectory() as folder:
            window=MainWindow(Path(folder))
            try:
                window.show();APP.processEvents()
                self.assertIsNone(window.session.sock)
                self.assertIsNone(window.amc_page.input_sample)
                self.assertIsNone(window.amc_page.result)
                self.assertEqual(window.result_paths,{})
                for attribute in ("mock","run_demo","start_mock","demo_button","sample_button"):
                    self.assertFalse(hasattr(window,attribute),attribute)
                self.assertFalse(hasattr(window.amc_page,"run_demo"))
                texts=[]
                for cls in (QLabel,QPushButton):
                    texts += [item.text() for item in window.findChildren(cls)]
                for combo in window.findChildren(QComboBox):
                    texts += [combo.itemText(i) for i in range(combo.count())]
                for value in texts:
                    self.assertFalse(any(word in value for word in ("演示","模拟","仿真")),value)
            finally:window.close();APP.processEvents()

    def test_three_algorithms_load_from_bins_without_creating_network_frames(self):
        from host615.ui import MainWindow
        with tempfile.TemporaryDirectory() as folder:
            window=MainWindow(Path(folder))
            try:
                with patch.object(window.session,"open") as connect,patch.object(window.session,"upload") as send:
                    window.load_local_result(FILES/"MIMO结果.bin")
                    self.assertEqual(window.result_keys[window.result_tabs.currentIndex()],"mimo")
                    self.assertEqual(window.format_combo.currentText(),"IQ · int16 小端")
                    self.assertIsNotNone(window.scatter.values)
                    self.assertIn("参考文件",window.preview_note.text())
                    window.load_local_result(FILES/"CDMA结果.bin")
                    self.assertEqual(window.result_keys[window.result_tabs.currentIndex()],"cdma")
                    self.assertIsNotNone(window.bit_plot.values)
                    self.assertIn("参考文件",window.preview_note.text())
                    window.load_local_result(FILES/"AMC_16QAM.bin")
                    self.assertEqual(window.result_keys[window.result_tabs.currentIndex()],"amc")
                    self.assertEqual(window.amc_page.result.winner,"16qam")
                    self.assertEqual(window.amc_page.source_badge.text(),"参考文件")
                    connect.assert_not_called();send.assert_not_called()
                self.assertEqual(window.records,[])
                self.assertEqual(window._frame_count,0)
                self.assertIsNone(window.session.sock)
                output=Path(folder)/"amc.png"
                window.amc_page.export_to(output)
                self.assertTrue(output.is_file())
                self.assertEqual(load_result(output.with_suffix(".bin")).source,"reference")
            finally:window.close();APP.processEvents()

    def test_raw_iq_does_not_invent_classification_and_bad_import_preserves_view(self):
        from host615.cnn_ui import AMCPage
        with tempfile.TemporaryDirectory() as folder:
            page=AMCPage(Path(folder))
            try:
                page.import_result(FILES/"AMC_QPSK.bin")
                iq_path=FILES.parent/"02_输入IQ"/"bpsk.npz"
                page.set_local_iq(iq_path)
                self.assertIsNone(page.result)
                self.assertEqual(page.class_metric.value.text(),"待分类")
                self.assertIsNotNone(page.features)
                self.assertTrue(all(value.text()=="—" for _,value in page.score_rows.values()))
                page.import_result(FILES/"AMC_8PSK.bin")
                invalid=Path(folder)/"bad.bin";invalid.write_bytes(b"invalid")
                with self.assertRaises(ValueError):page.import_result(invalid)
                self.assertEqual(page.result.winner,"8psk")
                self.assertNotIn("演示",page.process.toPlainText())
            finally:page.close();APP.processEvents()

    def test_legacy_settings_migrate_without_reusing_retired_files(self):
        from host615.ui import MainWindow
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)
            config={"network":{"algorithm":"sar","remote_ip":"192.168.1.15","remote_port":5002,"expected_bytes":4194304},
                    "files":{"DM":[str(FILES/"MIMO结果.bin")]},"preview":{"formats":{"sar":"IQ · int16 小端"},"width":1024}}
            (base/"settings.json").write_text(json.dumps(config),encoding="utf8")
            window=MainWindow(base)
            try:
                self.assertEqual(window.algorithm.currentData(),"mimo")
                self.assertEqual(window.expected.value(),65024)
                self.assertEqual(window.remote_ip.text(),"192.168.1.15")
                self.assertTrue(all(not row.paths for row in window.file_rows.values()))
            finally:window.close();APP.processEvents()
