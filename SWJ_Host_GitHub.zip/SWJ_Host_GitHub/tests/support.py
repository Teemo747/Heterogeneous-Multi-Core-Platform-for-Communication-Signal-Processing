"""Local-only UDP peer for protocol/UI verification; it does not compute 615 algorithms."""

import hashlib
import socket
import threading
import time
import numpy as np

from host615.protocol import ALGORITHMS, firmware_treats_as_control


def simulated_result(algorithm: str) -> bytes:
    if algorithm == "mimo":
        count = 65024 // 4
        rng = np.random.default_rng(615)
        constellation = rng.choice([-12000, 12000], (count, 2))
        return np.clip(constellation + rng.normal(0, 1700, (count, 2)),
                       -32768, 32767).astype("<i2").tobytes()
    if algorithm == "cdma":
        return np.random.default_rng(615).integers(0, 2, 128, dtype=np.int16).astype("<i2").tobytes()
    raise ValueError("模拟器不支持该算法")


class MockFPGA:
    def __init__(self, port=55001, drop_packet: int | None = None, frames: int = 1):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", port))
        self.sock.settimeout(.1)
        self.port = self.sock.getsockname()[1]
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True, name="615-local-mock")
        self.algorithm = "mimo"
        self.current = None
        self.buffer = bytearray()
        self.received = {}
        self.commands = []
        self.drop_packet = drop_packet
        self.frames = frames
        self.thread.start()

    def _run(self):
        while not self.stop_event.is_set():
            try:
                data, peer = self.sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                break
            if data in [a.command for a in ALGORITHMS.values()]:
                self.algorithm = next(k for k, a in ALGORITHMS.items() if a.command == data)
                self.commands.append(data)
            elif len(data) == 8 and data.startswith(b"hello"):
                self.sock.sendto(data, peer)
                # Match the real callback: hello does NOT clear accumulated bytes.
                self.current = data[-2:].decode("ascii").upper()
                self.commands.append(data)
            elif len(data) == 6 and data.startswith(b"end"):
                memory = data[-2:].decode("ascii").upper()
                self.received[memory] = bytes(self.buffer)
                self.buffer.clear()
                self.commands.append(data)
                if memory == "DM":
                    for _ in range(self.frames):
                        self._result(peer)
            else:
                self.buffer.extend(data)

    def _result(self, peer):
        for mask in (0x000F, 0x00FF, 0xFFFF if self.algorithm != "cdma" else 0x000F):
            self.sock.sendto(f"core16status{mask:04X}".encode(), peer)
            if self.stop_event.wait(.05):
                return
        self.sock.sendto(b"algor_time0123", peer)
        self.sock.sendto(b"core16finish", peer)
        data = simulated_result(self.algorithm)
        for index, start in enumerate(range(0, len(data), 1024)):
            if self.stop_event.is_set():
                return
            if index != self.drop_packet:
                self.sock.sendto(data[start:start + 1024], peer)
            time.sleep(.0004)
        self.sock.sendto(b"finished", peer)

    def close(self):
        self.stop_event.set()
        self.thread.join(2)
        self.sock.close()
