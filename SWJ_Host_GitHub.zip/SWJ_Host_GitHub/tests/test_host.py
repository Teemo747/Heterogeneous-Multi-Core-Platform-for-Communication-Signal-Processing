import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import hashlib
import json
from pathlib import Path
import socket
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np
from PyQt6.QtWidgets import QApplication

from host615.formats import bits_from_file, image_data, samples
from support import MockFPGA, simulated_result
from host615.protocol import ALGORITHMS, file_packets, firmware_treats_as_control, parse_control
from host615.session import FrameWriter, Session, Settings

APP = QApplication.instance() or QApplication([])


def wait_until(predicate, timeout=8):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        APP.processEvents()
        if predicate():
            return
        time.sleep(.005)
    raise AssertionError("等待条件超时")


def free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class ProtocolTests(unittest.TestCase):
    def test_real_control_messages(self):
        self.assertEqual(parse_control(b"core16status8001"), ("cores", 0x8001))
        self.assertEqual(parse_control(b"algor_time0123"), ("algorithm_time", 0x123))
        self.assertEqual(parse_control(b"sar_stage_time0010002000300040"),
                         ("sar_times", [16, 32, 48, 64]))
        self.assertEqual(parse_control(b"msg_sar_stage05"), ("sar_stage", 5))
        for raw in (b"\x00\xfffinished", b"finished\x00", b"core16statusXYZ1",
                    b"core16status00010", b"hello_pm-extra"):
            self.assertIsNone(parse_control(raw))

    def test_command_like_file_tails_preserve_all_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            for tail in (b"end_pm", b"end_xx", b"algo_SAR", b"helloxxx"):
                for prefix in (b"", b"\x01" * 1024):
                    path = Path(folder) / "data.bin"
                    original = prefix + tail
                    path.write_bytes(original)
                    packets = list(file_packets([path]))
                    self.assertEqual(b"".join(packets), original)
                    self.assertTrue(all(not firmware_treats_as_control(p) for p in packets))

    def test_multiple_files_concatenate_without_padding(self):
        with tempfile.TemporaryDirectory() as folder:
            paths = [Path(folder) / "a", Path(folder) / "b"]
            paths[0].write_bytes(b"\x00" * 1030)
            paths[1].write_bytes(b"\xff" * 77)
            self.assertEqual(b"".join(file_packets(paths)), paths[0].read_bytes() + paths[1].read_bytes())

    def test_frame_lengths_and_sidecar(self):
        with tempfile.TemporaryDirectory() as folder:
            settings = Settings(output_dir=folder, expected_bytes=4)
            frame = FrameWriter(settings, 1)
            frame.write(b"\x00\x01\x02\x03")
            result = frame.finish()
            self.assertTrue(result["complete"])
            self.assertFalse(".partial" in result["path"])
            self.assertEqual(Path(result["path"]).read_bytes(), b"\x00\x01\x02\x03")
            self.assertEqual(result["sha256"], hashlib.sha256(b"\x00\x01\x02\x03").hexdigest())
            frame = FrameWriter(settings, 2)
            frame.write(b"\x00")
            result = frame.finish()
            self.assertFalse(result["complete"])
            self.assertIn(".partial.bin", result["path"])
            self.assertFalse(json.loads(Path(result["path"]).with_suffix(".json").read_text())["complete"])

    def test_selectable_iq_and_bit_formats(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "iq.bin"
            path.write_bytes(np.array([1, -2, 3, 4], dtype="<i2").tobytes())
            np.testing.assert_array_equal(samples(str(path), "IQ · int16 小端"), [1 - 2j, 3 + 4j])
            path.write_text("0\n1\n1\n0\n", encoding="ascii")
            np.testing.assert_array_equal(bits_from_file(str(path)), [0, 1, 1, 0])
            with self.assertRaises(ValueError):
                image_data(np.ones(2), 1024, 1024)

    def test_raw_preview_rejects_extra_samples_and_misaligned_iq(self):
        with self.assertRaises(ValueError):
            image_data(np.ones(17), 4, 4)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "partial.bin"
            path.write_bytes(b"\x01\x00\x02")
            with self.assertRaisesRegex(ValueError, "整数倍"):
                samples(str(path), "IQ · int16 小端")


class NetworkTests(unittest.TestCase):
    def test_retired_telemetry_is_ignored_instead_of_saved_as_result_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0); session = None
            try:
                session, events = self.make_session(folder, mock, expected_bytes=4)
                peer = ("127.0.0.1", session.settings.local_port)
                mock.sock.sendto(b"msg_sar_stage05", peer)
                mock.sock.sendto(b"sar_stage_time0010002000300040", peer)
                mock.sock.sendto(b"finished", peer)
                wait_until(lambda: any(e["kind"] == "log" and "本帧没有数据" in e["text"] for e in events))
                self.assertFalse(any(e["kind"] == "frame" for e in events))
                payload = b"\x01\x02\x03\x04"
                mock.sock.sendto(payload, peer); mock.sock.sendto(b"finished", peer)
                wait_until(lambda: any(e["kind"] == "frame" for e in events))
                frame = next(e for e in events if e["kind"] == "frame")
                self.assertEqual(Path(frame["path"]).read_bytes(), payload)
            finally:
                if session:
                    session.close()
                mock.close()

    def make_session(self, folder, mock, algorithm="mimo", **overrides):
        settings = Settings(local_ip="127.0.0.1", local_port=free_port(),
                            remote_ip="127.0.0.1", remote_port=mock.port,
                            algorithm=algorithm, expected_bytes=ALGORITHMS[algorithm].result_bytes,
                            output_dir=folder, file_gap_ms=100, rate_kib=4096, handshake_ms=200)
        for key, value in overrides.items():
            setattr(settings, key, value)
        session = Session()
        events = []
        session.event.connect(events.append)
        session.open(settings)
        wait_until(lambda: session.verified and not session.busy)
        return session, events

    def test_supported_algorithms_over_actual_udp(self):
        for key in ALGORITHMS:
            with self.subTest(algorithm=key), tempfile.TemporaryDirectory() as folder:
                mock = MockFPGA(port=0)
                session = None
                try:
                    session, events = self.make_session(folder, mock, key)
                    paths = []
                    for index, memory in enumerate(("PM", "CM", "DM")):
                        path = Path(folder) / f"{memory}.bin"
                        path.write_bytes(bytes(range(256)) * (index + 1) + b"end_pm")
                        paths.append(path)
                    session.upload([(m, [p]) for m, p in zip(("PM", "CM", "DM"), paths)])
                    wait_until(lambda: any(e["kind"] == "frame" for e in events), 15)
                    frame = next(e for e in events if e["kind"] == "frame")
                    self.assertTrue(frame["complete"], frame)
                    self.assertEqual(Path(frame["path"]).read_bytes(), simulated_result(key))
                    for memory, path in zip(("PM", "CM", "DM"), paths):
                        self.assertEqual(mock.received[memory], path.read_bytes())
                    self.assertEqual([c for c in mock.commands if c.startswith(b"end_")],
                                     [b"end_pm", b"end_cm", b"end_dm"])
                    self.assertTrue(any(e["kind"] == "telemetry" and e["name"] == "cores" for e in events))
                finally:
                    if session:
                        session.close()
                    mock.close()

    def test_missing_result_packet_is_saved_as_partial(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0, drop_packet=2)
            session = None
            try:
                session, events = self.make_session(folder, mock)
                path = Path(folder) / "dm"
                path.write_bytes(b"\0" * 1024)
                session.upload([("DM", [path])])
                wait_until(lambda: any(e["kind"] == "frame" for e in events))
                frame = next(e for e in events if e["kind"] == "frame")
                self.assertFalse(frame["complete"])
                self.assertEqual(frame["bytes"], 65024 - 1024)
                self.assertIn(".partial.bin", frame["path"])
            finally:
                if session:
                    session.close()
                mock.close()

    def test_cancel_partial_upload_requires_board_reset(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0)
            session = None
            try:
                session, events = self.make_session(folder, mock, rate_kib=16)
                path = Path(folder) / "dm"
                path.write_bytes(bytes(range(256)) * 1024)
                session.upload([("DM", [path])])
                wait_until(lambda: any(e["kind"] == "tx_progress" for e in events))
                session.cancel()
                wait_until(lambda: not session.busy)
                self.assertTrue(session.needs_board_reset)
                self.assertNotIn(b"end_dm", mock.commands)
                with self.assertRaises(RuntimeError):
                    session.upload([("DM", [path])])
            finally:
                if session:
                    session.close()
                mock.close()

    def test_failed_reprobe_revokes_confirmation_and_blocks_upload(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0)
            session = None
            try:
                session, events = self.make_session(folder, mock, handshake_ms=100)
                mock.close()
                session.probe("CM")
                wait_until(lambda: not session.busy)
                self.assertFalse(session.verified)
                self.assertTrue(any(e["kind"] == "link" and e["state"] == "unverified" for e in events))
                path = Path(folder) / "pm.bin"
                path.write_bytes(b"615")
                with self.assertRaisesRegex(RuntimeError, "握手"):
                    session.upload([("PM", [path])])
            finally:
                if session:
                    session.close()
                mock.close()

    def test_socket_bind_errors_explain_local_address_and_port(self):
        for code, message in ((10049, "实际网卡地址"), (10048, "端口.*占用")):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as folder:
                session = Session()
                with patch("host615.session.socket.socket") as constructor:
                    constructor.return_value.bind.side_effect = OSError(code, "socket bind failed")
                    with self.assertRaisesRegex(ValueError, message):
                        session.open(Settings(output_dir=folder))
                    constructor.return_value.close.assert_called_once()
                self.assertIsNone(session.sock)
                self.assertFalse(session.verified)

    def test_unreachable_peer_does_not_report_verified(self):
        with tempfile.TemporaryDirectory() as folder:
            session = Session()
            try:
                session.open(Settings(local_ip="127.0.0.1", local_port=free_port(),
                                      remote_ip="127.0.0.1", remote_port=free_port(),
                                      output_dir=folder, handshake_ms=100))
                wait_until(lambda: not session.busy)
                self.assertFalse(session.verified)
            finally:
                session.close()

    def test_continuous_frames_remain_separate(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0, frames=3)
            session = None
            try:
                session, events = self.make_session(folder, mock)
                path = Path(folder) / "dm"
                path.write_bytes(b"\0" * 1024)
                session.upload([("DM", [path])])
                wait_until(lambda: sum(e["kind"] == "frame" for e in events) == 3)
                frames = [e for e in events if e["kind"] == "frame"]
                self.assertEqual(len({f["path"] for f in frames}), 3)
                self.assertTrue(all(f["complete"] for f in frames))
                self.assertTrue(all(Path(f["path"]).read_bytes() == simulated_result("mimo") for f in frames))
            finally:
                if session:
                    session.close()
                mock.close()

    def test_disconnecting_retains_unfinished_frame(self):
        with tempfile.TemporaryDirectory() as folder:
            mock = MockFPGA(port=0)
            session = None
            try:
                session, events = self.make_session(folder, mock)
                mock.sock.sendto(b"\x07" * 1024, ("127.0.0.1", session.settings.local_port))
                wait_until(lambda: session._frame is not None)
                session.close()
                APP.processEvents()
                frame = next(e for e in events if e["kind"] == "frame")
                self.assertFalse(frame["complete"])
                self.assertEqual(frame["reason"], "disconnected")
                self.assertEqual(Path(frame["path"]).read_bytes(), b"\x07" * 1024)
            finally:
                if session:
                    session.close()
                mock.close()


